# DUCC Website

# This website will replace the existing DUCC website [https://durhamunicanoe.co.uk](https://durhamunicanoe.co.uk), thus it is a bit more complex that the assignment intended. So, sorry about that!

## API Documentation
The API documentation is generated from `public/openapi.json`.
- View the documentation: [public/openapi.html](public/openapi.html)

## Running
npm install

I would recommend using `npm run dev` as it seeds the database, but `npm start` will also work. 

## Directory Structure
- `public/`: Frontend assets and client-side logic.
  - `js/widgets/`: Reusable UI components.
  - `js/pages/`: Page-specific logic.
- `server/`: Backend logic.
  - `server/db/`: SQLite drivers and initialization scripts.
  - `server/api/`: API route handlers.
  - `server/rules/`: Security rules. 
- `src/`: SASS partials.
- `tests/`: Vitest tests.