/**
 * utils.js
 * 
 * Frontend utility functions.
 */

/** Format number with ordinal suffix. */
export function getOrdinal(n) {
    if (n === undefined || n === null || n === '-' || n < 1) return '-';
    
    const s = ["th", "st", "nd", "rd"];
    const v = n % 100;
    
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/** Debounce function execution. */
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/** Retrieve cookie value. */
export function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}
