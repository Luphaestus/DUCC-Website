/**
 * events.js
 * 
 * Application events definitions.
 */

import { Event } from './event.js';

/** Transaction event. */
const BalanceChangedEvent = new Event();


/** Name change event. */
const FirstNameChangedEvent = new Event();

/** Legal waiver event. */
const LegalEvent = new Event();


/** Login event. */
const LoginEvent = new Event();

/** View change event. */
const ViewChangedEvent = new Event();

/** Attendance/Waitlist change event. */
const EventAttendanceChangedEvent = new Event();

/** Connection lost event. */
const NoInternetEvent = new Event();

export { BalanceChangedEvent, FirstNameChangedEvent, LegalEvent, LoginEvent, ViewChangedEvent, EventAttendanceChangedEvent, NoInternetEvent };