/**
 * event.js
 * 
 * Pub/Sub event pattern.
 */

class Event {
    constructor() {
        /** List of registered callback functions. */
        this.subscribers = new Set();
    }

    /** Register callback. */
    subscribe(callback) {
        this.subscribers.add(callback);
        return () => this.unsubscribe(callback);
    }

    /** Register one-time callback. */
    once(callback) {
        const onceWrapper = (data) => {
            callback(data);
            this.unsubscribe(onceWrapper);
        };
        return this.subscribe(onceWrapper);
    }

    /** Remove callback. */
    unsubscribe(callback) {
        this.subscribers.delete(callback);
    }

    /** Trigger event. */
    notify(data) {
        this.subscribers.forEach(sub => {
            try {
                sub(data);
            } catch (error) {
                console.error("Error in event subscriber:", error);
            }
        });
    }

    /** Remove all subscribers. */
    clear() {
        this.subscribers.clear();
    }
}

export { Event };