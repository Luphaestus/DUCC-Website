/**
 * modal.js
 * 
 * Modal utilities.
 */

import { Modal } from '/js/widgets/Modal.js';

/** Mount modal to DOM. */
function mountModal(modal) {
    const wrapper = document.createElement('div');
    wrapper.innerHTML = modal.getHTML();
    const modalEl = wrapper.firstElementChild;
    document.body.appendChild(modalEl);

    modal.attachListeners();
    modal.show();

    return {
        element: modalEl,
        cleanup: () => {
            modal.hide();
            setTimeout(() => {
                if (document.body.contains(modalEl)) document.body.removeChild(modalEl);
            }, 300);
        }
    };
}

/** Show confirm modal. */
export function showConfirmModal(title, message) {
    return new Promise((resolve) => {
        const modal = new Modal({
            id: `confirm-modal-${Date.now()}`,
            title: title,
            content: `
                <p>${message}</p>
                <div class="modal-actions">
                    <button class="btn-cancel" id="confirm-cancel">Cancel</button>
                    <button class="btn-confirm" id="confirm-ok">Confirm</button>
                </div>
            `,
            onClose: () => {
                mount.cleanup();
                resolve(false);
            }
        });

        const mount = mountModal(modal);

        mount.element.querySelector('#confirm-ok').onclick = () => {
            mount.cleanup();
            resolve(true);
        };

        mount.element.querySelector('#confirm-cancel').onclick = () => {
            mount.cleanup();
            resolve(false);
        };
    });
}

/** Show password confirmation modal. */
export function showPasswordModal(title, message) {
    return new Promise((resolve) => {
        const modal = new Modal({
            id: `password-modal-${Date.now()}`,
            title: title,
            content: `
                <p>${message}</p>
                <input type="password" id="confirm-password" placeholder="Enter your password">
                <div class="modal-actions">
                    <button class="btn-cancel" id="confirm-cancel">Cancel</button>
                    <button class="btn-confirm" id="confirm-ok">Confirm</button>
                </div>
            `,
            onClose: () => {
                mount.cleanup();
                resolve(null);
            }
        });

        const mount = mountModal(modal);
        const input = mount.element.querySelector('#confirm-password');
        input.focus();

        const confirm = () => {
            const password = input.value;
            if (password) {
                mount.cleanup();
                resolve(password);
            }
        };

        mount.element.querySelector('#confirm-ok').onclick = confirm;
        mount.element.querySelector('#confirm-cancel').onclick = () => {
            mount.cleanup();
            resolve(null);
        };
        input.onkeydown = (e) => { if (e.key === 'Enter') confirm(); };
    });
}

/** Show change password modal. */
export function showChangePasswordModal() {
    return new Promise((resolve) => {
        const modal = new Modal({
            id: `change-pw-modal-${Date.now()}`,
            title: 'Change Password',
            content: `
                <p>Please enter your current password and a new password.</p>
                <input type="password" id="current-password" placeholder="Current Password">
                <input type="password" id="new-password" placeholder="New Password">
                <div class="modal-actions">
                    <button class="btn-cancel" id="confirm-cancel">Cancel</button>
                    <button class="btn-confirm" id="confirm-ok">Change Password</button>
                </div>
            `,
            onClose: () => {
                mount.cleanup();
                resolve(null);
            }
        });

        const mount = mountModal(modal);

        const currentInput = mount.element.querySelector('#current-password');
        const newInput = mount.element.querySelector('#new-password');
        currentInput.focus();

        const confirm = () => {
            const currentPassword = currentInput.value;
            const newPassword = newInput.value;
            if (currentPassword && newPassword) {
                mount.cleanup();
                resolve({ currentPassword, newPassword });
            }
        };

        mount.element.querySelector('#confirm-ok').onclick = confirm;
        mount.element.querySelector('#confirm-cancel').onclick = () => {
            mount.cleanup();
            resolve(null);
        };
        newInput.onkeydown = (e) => { if (e.key === 'Enter') confirm(); };
    });
}