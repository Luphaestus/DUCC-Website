/**
 * history.js
 * 
 * Internal navigation history management.
 */

import { ViewChangedEvent } from './events/events.js';

let previousPath = [];
let currentPath = window.location.pathname + window.location.search;

/** Update history stack on view change. */
ViewChangedEvent.subscribe(({ path }) => {
    previousPath.push(currentPath);
    currentPath = path;
});

/** Pop and return last path. */
export const getPreviousPath = () => previousPath.pop();

/** Check if history exists. */
export const hasHistory = () => previousPath.length > 0;

/** Get current path. */
export const getCurrentPath = () => currentPath;