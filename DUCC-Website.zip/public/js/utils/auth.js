/**
 * auth.js
 * 
 * Client-side authentication protection.
 */

import { apiRequest } from './api.js';
import { switchView } from './view.js';

/** Check auth status. */
export async function requireAuth() {
    try {
        const data = await apiRequest('GET', '/api/auth/status', true);
        
        if (!data.authenticated) {
            sessionStorage.setItem('redirect_after_login', window.location.pathname + window.location.search);
            switchView('/unauthorised');
            return false;
        }
        
        return true;
    } catch (error) {
        console.error("Auth check failed:", error);
        switchView('/unauthorised');
        return false;
    }
}