/**
 * status.js
 * 
 * Status indicator component.
 */

import { CHECK_SVG, BRIGHTNESS_ALERT_SVG } from '../../images/icons/outline/icons.js';

/** Render status indicator. */
export const StatusIndicator = ({ active, activeText = 'Active', inactiveText = 'Action Required', content }) => `
    <div class="status-indicator-box ${active ? 'status-green' : 'status-red'}">
        <div class="indicator-header">
            ${active ? CHECK_SVG : BRIGHTNESS_ALERT_SVG} 
            <span>${active ? activeText : inactiveText}</span>
        </div>
        <div class="indicator-body">
            ${content}
        </div>
    </div>
`;