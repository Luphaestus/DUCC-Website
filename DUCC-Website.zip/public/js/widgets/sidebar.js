/**
 * sidebar.js
 * 
 * Dashboard sidebar component.
 */

/** Render Sidebar HTML. */
export const Sidebar = (items = []) => `
    <nav class="dashboard-sidebar glass-panel">
        ${items.map(item => `
            <button class="nav-item ${item.active ? 'active' : ''} ${item.classes || ''}" 
                ${item.id ? `data-tab="${item.id}"` : ''} 
                ${item.actionId ? `id="${item.actionId}"` : ''}>
                ${item.icon || ''} ${item.label}
            </button>
        `).join('')}
    </nav>
`;

/** Initialize sidebar logic. */
export function initSidebar(defaultTab = 'overview', onTabChange) {
    const tabs = document.querySelectorAll('.nav-item[data-tab]');
    const sections = document.querySelectorAll('.dashboard-section');

    function setActive(tabName) {
        tabs.forEach(btn => {
            if (btn.dataset.tab === tabName) btn.classList.add('active');
            else btn.classList.remove('active');
        });

        sections.forEach(sec => sec.classList.remove('active'));
        const activeSection = document.getElementById(`tab-${tabName}`);
        if (activeSection) activeSection.classList.add('active');

        if (onTabChange) onTabChange(tabName);
    }

    tabs.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;
            const url = new URL(window.location);
            url.searchParams.set('tab', tabName);
            window.history.pushState({}, '', url);
            
            setActive(tabName);
        });
    });

    const params = new URLSearchParams(window.location.search);
    const initialTab = params.get('tab') || defaultTab;
    setActive(initialTab);

    return { setActive };
}