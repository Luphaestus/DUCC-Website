/**
 * item_list.js
 * 
 * Generic item list widget.
 */

/** Render item list. */
export const ItemList = (items = [], renderItem) => {
    if (!items || items.length === 0) {
        return '<p class="empty-text">No items found.</p>';
    }

    return `
    <div class="item-list">
        ${items.map(item => renderItem(item)).join('')}
    </div>
    `;
};

/** Render standard list item. */
export const StandardListItem = ({
    icon = '',
    iconClass = '',
    title = '',
    subtitle = '',
    value = '',
    valueClass = '',
    extra = '',
    actions = '',
    content = '',
    classes = '',
    dataAttributes = ''
}) => `
    <div class="list-item glass-panel ${classes}" ${dataAttributes}>
        <div class="item-icon ${iconClass}">${icon}</div>
        <div class="item-details">
            <span class="item-title">${title}</span>
            <span class="item-subtitle">${subtitle}</span>
        </div>
        ${content}
        <div class="item-value-group">
            <span class="item-value ${valueClass}">${value}</span>
            ${extra ? `<span class="item-extra">${extra}</span>` : ''}
        </div>
        ${actions ? `<div class="item-actions">${actions}</div>` : ''}
    </div>
`;