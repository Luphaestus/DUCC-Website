/**
 * TabNav.js
 * 
 * Tab navigation with sliding background.
 */

export class TabNav {
    /** Initialize navigation. */
    constructor({ id, tabs, activeKey, classes = '' }) {
        this.id = id;
        this.tabs = tabs;
        this.activeKey = activeKey;
        this.classes = classes;
    }

    /** Generate HTML. */
    getHTML() {
        const items = this.tabs.map(tab => {
            const dataAttrs = Object.entries(tab.data || {})
                .map(([k, v]) => `data-${k}="${v}"`)
                .join(' ');
            
            const navAttr = tab.link ? `data-nav="${tab.link}"` : '';

            return `
                <button ${navAttr} ${dataAttrs} class="tab-btn ${this.activeKey === tab.key ? 'active' : ''}" data-key="${tab.key}">
                    ${tab.label}
                </button>
            `;
        }).join('');

        return `
            <nav class="toggle-group ${this.classes}" id="${this.id}">
                <div class="toggle-bg"></div>
                ${items}
            </nav>
        `;
    }

    /** Initialize logic. */
    init() {
        const element = document.getElementById(this.id);
        if (!element) return;

        if (element.dataset.initialised === 'true') {
            if (element._syncToggleGroup) element._syncToggleGroup();
            return;
        }

        const bg = element.querySelector('.toggle-bg');
        if (!bg) return;

        const sync = (silent = false) => {
            const active = element.querySelector('.tab-btn.active') || element.querySelector('button.active');
            if (active) {
                if (silent) bg.style.transition = 'none';
                
                const pos = {
                    width: `${active.offsetWidth}px`,
                    height: `${active.offsetHeight}px`,
                    left: `${active.offsetLeft}px`,
                    top: `${active.offsetTop}px`
                };

                bg.style.setProperty('--tab-width', pos.width);
                bg.style.setProperty('--tab-height', pos.height);
                bg.style.setProperty('--tab-left', pos.left);
                bg.style.setProperty('--tab-top', pos.top);
                
                if (element.id) {
                    window.__lastTogglePositions = window.__lastTogglePositions || {};
                    window.__lastTogglePositions[element.id] = pos;
                }

                if (silent) {
                    bg.offsetHeight; 
                    bg.style.transition = '';
                }
            }
        };

        element._syncToggleGroup = sync;
        element.dataset.initialised = 'true';

        const savedPos = element.id ? (window.__lastTogglePositions && window.__lastTogglePositions[element.id]) : null;
        
        if (savedPos) {
            bg.style.transition = 'none';
            bg.style.setProperty('--tab-width', savedPos.width);
            bg.style.setProperty('--tab-height', savedPos.height);
            bg.style.setProperty('--tab-left', savedPos.left);
            bg.style.setProperty('--tab-top', savedPos.top);
            bg.offsetHeight; 
            bg.style.transition = '';
            requestAnimationFrame(() => sync(false));
        } else {
            sync(true);
        }

        window.addEventListener('resize', () => sync());
        bg.addEventListener('transitionend', () => sync());
    }

    /** Helper to init existing elements. */
    static initElement(element) {
        if (!element) return;
        const id = element.id || `nav-${Math.random().toString(36).substr(2, 9)}`;
        if (!element.id) element.id = id;
        
        const nav = new TabNav({ id, tabs: [], activeKey: '' });
        nav.init();
    }
}