/**
 * Tag.js
 * 
 * Tag badge widget.
 */

export class Tag {
    /** Calculate contrast colour. */
    static getContrastColour(hexColour) {
        // code adapted from https://optional.is/required/2011/01/12/maximum-color-contrast/
        if (!hexColour || !hexColour.startsWith('#')) return 'white';
        
        let hex = hexColour.replace('#', '');
        
        if (hex.length === 3) {
            hex = hex.split('').map(c => c + c).join('');
        }
        
        if (hex.length > 6) {
            hex = hex.substring(0, 6);
        }

        if (hex.length !== 6) return 'white';

        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        
        if (isNaN(r) || isNaN(g) || isNaN(b)) return 'white';

        const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
        return (yiq >= 128) ? 'black' : 'white';
    }

    /** Render tag badge. */
    static render(tag, extraClasses = '', extraStyles = '') {
        const colour = tag.color || 'var(--pico-primary)';
        const textColour = Tag.getContrastColour(tag.color);
        return `<span class="tag-badge ${extraClasses}" style="--tag-colour: ${colour}; --tag-text-colour: ${textColour}; ${extraStyles}">${tag.name}</span>`;
    }

    /** Render list of tags. */
    static renderList(tags, extraClasses = '') {
        if (!tags || tags.length === 0) return '';
        return tags.map(tag => Tag.render(tag, extraClasses)).join('');
    }
}