/**
 * accent_panel.js
 * 
 * Reusable Accent Panel Component.
 */

/** Render accent panel. */
export const AccentPanel = ({ title, text, buttonText, buttonId, classes = '' }) => `
    <div class="accent-panel ${classes}">
        <div class="panel-content">
            <h2>${title}</h2>
            <p>${text}</p>
        </div>
        <div class="panel-action">
            <button id="${buttonId}">${buttonText}</button>
        </div>
    </div>
`;