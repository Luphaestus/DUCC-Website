/**
 * value_header.js
 * 
 * Generic Value Header Widget.
 */

/** Render value header. */
export const ValueHeader = ({
    title = '',
    value = '',
    valueId = '',
    actions = '',
    valueClass = '',
    classes = '',
    id = ''
} = {}) => {
    return `
    <div class="value-header ${classes}" ${id ? `id="${id}"` : ''}>
        <div class="value-info">
            <span class="value-title">${title}</span>
            <span class="value-display ${valueClass}" ${valueId ? `id="${valueId}"` : ''}>${value}</span>
        </div>
        <div class="value-actions">
            ${actions}
        </div>
    </div>
    `;
};

/** Update value display. */
export const updateValueDisplay = (valueId, value, valueClass = null) => {
    const el = document.getElementById(valueId);
    if (el) {
        el.textContent = value;
        if (valueClass !== null) {
            el.className = `value-display ${valueClass}`;
        }
    }
};