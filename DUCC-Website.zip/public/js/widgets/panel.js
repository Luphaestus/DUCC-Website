/**
 * panel.js
 * 
 * Reusable glass panel.
 */

/** Render glass panel with optional header. */
export const Panel = ({ id = '', title, icon = '', content = '', action = '', classes = '' }) => `
    <div ${id ? `id="${id}"` : ''} class="panel-widget ${classes}">
        ${title ? `
        <div class="box-header">
            <h3>${icon} ${title}</h3>
            ${action}
        </div>
        ` : ''}
        ${content}
    </div>
`;