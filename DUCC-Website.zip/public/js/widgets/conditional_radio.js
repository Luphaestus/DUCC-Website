/**
 * conditional_radio.js
 * 
 * Yes/No toggle with conditional input reveal.
 */

/** Render conditional radio group. */
export const ConditionalRadio = ({ legend, groupName, yesId, noId, detailId, detailPlaceholder }) => `
    <fieldset>
        <legend>${legend}</legend>
        <div class="radio-group">
            <label><input type="radio" id="${yesId}" name="${groupName}" value="yes"> Yes</label>
            <label><input type="radio" id="${noId}" name="${groupName}" value="no"> No</label>
        </div>
        <input type="text" id="${detailId}" class="conditional-reveal collapsed" name="${groupName}-detail" placeholder="${detailPlaceholder}">
    </fieldset>
`;

/** Initialize toggle logic. */
export function initConditionalRadio(yesId, noId, detailId) {
    const yesBtn = document.getElementById(yesId);
    const noBtn = document.getElementById(noId);
    const detailInput = document.getElementById(detailId);

    if (!yesBtn || !noBtn || !detailInput) return;

    const updateVisibility = () => {
        if (yesBtn.checked) {
            detailInput.classList.remove('collapsed');
        } else {
            detailInput.classList.add('collapsed');
            detailInput.value = '';
            detailInput.removeAttribute('aria-invalid');
        }
    };

    yesBtn.addEventListener('change', updateVisibility);
    noBtn.addEventListener('change', updateVisibility);
    
    updateVisibility();
}