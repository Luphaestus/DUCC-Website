/**
 * notification.js
 * 
 * Toast notification system.
 */

/** Notification types. */
class NotificationTypes {
    static INFO = 'info';
    static SUCCESS = 'success';
    static WARNING = 'warning';
    static ERROR = 'error';
}

const activeCallers = new Map();

/** Remove notification. */
function closeNotification(notification) {
    if (!notification || notification.classList.contains('fade-out')) return;
    
    // Cleanup reference if this notification was tracked
    const callerId = notification.dataset.caller;
    if (callerId && activeCallers.get(callerId)?.element === notification) {
        activeCallers.delete(callerId);
    }

    const fadeOutListener = () => {
        notification.remove();
    };
    notification.addEventListener('animationend', fadeOutListener, { once: true });
    
    // Fallback if animation fails
    setTimeout(() => { if (notification.parentNode) notification.remove(); }, 500);

    notification.classList.add('fade-out');
}

/** Show notification. */
function notify(title, message, type = NotificationTypes.INFO, duration = 5000, uniqueCaller = null) {
    const notificationContainer = document.getElementById('notification-container');
    if (!notificationContainer) return () => {};

    let notification;

    // Check for existing notification from the same caller.
    if (uniqueCaller && activeCallers.has(uniqueCaller)) {
        const existing = activeCallers.get(uniqueCaller);
        notification = existing.element;
        clearTimeout(existing.timeout);
        
        notification.className = 'notification';
        notification.classList.add(`notification-${type}`);
    } else {
        notification = document.createElement('div');
        notification.classList.add('notification', `notification-${type}`);
        if (uniqueCaller) notification.dataset.caller = uniqueCaller;

        // Allow user to dismiss by clicking
        notification.addEventListener('click', () => {
            closeNotification(notification);
        });

        notificationContainer.appendChild(notification);
    }

    notification.innerHTML = `<strong>${title}</strong>${message ? `<p>${message}</p>` : ''}`;

    // Schedule automatic removal
    const timeout = setTimeout(() => {
        closeNotification(notification);
    }, duration);

    if (uniqueCaller) {
        activeCallers.set(uniqueCaller, {
            element: notification,
            timeout: timeout
        });
    }

    return () => {
        clearTimeout(timeout);
        closeNotification(notification);
    };
}

export { notify, NotificationTypes };