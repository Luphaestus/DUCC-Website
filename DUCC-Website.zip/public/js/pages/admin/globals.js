/**
 * globals.js
 * 
 * Global settings management.
 */

import { apiRequest } from '/js/utils/api.js';
import { adminContentID, renderAdminNavBar } from './admin.js';
import { notify } from '/js/components/notification.js';
import { UploadWidget } from '/js/widgets/upload/UploadWidget.js';
import { Panel } from '/js/widgets/panel.js';
import { renderLibrary } from '../../widgets/upload/Library.js';
import { SAVE_SVG, IMAGE_SVG, UPLOAD_SVG, CLOSE_SVG } from '../../../images/icons/outline/icons.js';
import { Modal } from '/js/widgets/Modal.js';

let imagePickerModal = null;
let modalUploadWidget = null;

/** Render globals dashboard. */
export async function renderManageGlobals() {
    const adminContent = document.getElementById(adminContentID);
    if (!adminContent) return;

    imagePickerModal = new Modal({
        id: 'image-picker-modal',
        title: 'Choose Image',
        content: `<div id="modal-upload-widget"></div>`,
        contentClasses: 'glass-panel modal-lg'
    });

    adminContent.innerHTML = `
        <div class="glass-layout">
            <div class="glass-toolbar">
                 ${await renderAdminNavBar('globals')}
            </div>
                <div class="glass-table-container">
                    <div class="table-responsive">
                        <table class="glass-table">
                            <thead>
                                <tr>
                                    <th>Setting</th>
                                    <th>Description</th>
                                    <th>Value</th>
                                    <th class="action-col">Action</th>
                                </tr>
                            </thead>
                            <tbody id="globals-table-body">
                                <tr><td colspan="4" class="loading-cell">Loading...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>

        ${imagePickerModal.getHTML()}
    `;

    setupModalListeners();
    await fetchAndRenderGlobals();
}

/** Initialize image picker modal. */
function setupModalListeners() {
    if (!imagePickerModal) return;

    imagePickerModal.attachListeners();

    // Initialise Upload Widget
    modalUploadWidget = new UploadWidget('modal-upload-widget', {
        mode: 'inline',
        selectMode: 'single',
        autoUpload: true,
        enableLibrary: false,
        inlineLibrary: true,
        enableRemove: false,
        onImageSelect: ({ url, id }) => {
            selectImage(url);
        },
        onUploadError: (err) => {
            notify('Upload failed', err.message, 'error');
        }
    });
}

let activePickerKey = null;

async function selectImage(url) {
    if (!activePickerKey) return;

    const input = document.querySelector(`.global-input[data-key="${activePickerKey}"]`);
    if (input) {
        input.value = url;

        const previews = document.querySelectorAll(`.image-preview-global[data-key="${activePickerKey}"]`);
        previews.forEach(preview => {
            preview.style.backgroundImage = `url('${url}')`;
            const img = preview.querySelector('img');
            if (img) img.src = url;
        });

        const globals = await apiRequest('GET', '/api/globals').then(res => res.res || {});
        const displayName = globals[activePickerKey]?.name || activePickerKey;
        await updateGlobal(activePickerKey, url, displayName);
    }

    if (imagePickerModal) imagePickerModal.close();
}

/** Fetch and render globals. */
async function fetchAndRenderGlobals() {
    const tbody = document.getElementById('globals-table-body');
    if (!tbody) return;

    try {
        const globals = await apiRequest('GET', '/api/globals').then(res => res.res || []).catch(() => []);

        if (Object.keys(globals).length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-cell">No settings found.</td></tr>';
            return;
        }

        tbody.innerHTML = Object.entries(globals).map(([key, value]) => {
            const displayName = value?.name || key;
            const description = value?.description || '';
            const type = value?.type || "text";

            let valueHtml = '';
            let actionHtml = '';

            if (type === 'image') {
                valueHtml = `
                    <div class="image-global-display">
                        <div class="image-preview-global" data-key="${key}" style="background-image: url('${value?.data || '/images/misc/ducc.png'}')">
                            <img src="${value?.data || '/images/misc/ducc.png'}" class="uncropped-hover-preview">
                        </div>
                        <input type="hidden" class="global-input" data-key="${key}" value="${value?.data}">
                    </div>
                `;
                actionHtml = `<button class="small-btn picker-btn" data-key="${key}" title="Change Image">${IMAGE_SVG}</button>`;
            } else {
                valueHtml = `<input type="${type}" class="global-input modern-input" data-key="${key}" value="${value?.data}">`;
                actionHtml = `<button class="save-global-btn icon-btn" data-key="${key}" title="Save">${SAVE_SVG}</button>`;
            }

            return `
                    <tr class="global-row" data-key="${key}">
                        <td data-label="Setting" class="primary-text"><strong>${displayName}</strong></td>
                        <td data-label="Description" class="description-cell">${description}</td>
                        <td data-label="Value">${valueHtml}</td>
                        <td data-label="Actions">${actionHtml}</td>
                    </tr>`;
        }).join('');

        tbody.querySelectorAll('.picker-btn').forEach(btn => {
            btn.onclick = () => {
                activePickerKey = btn.dataset.key;
                if (imagePickerModal) {
                    imagePickerModal.show();

                    // Provide current value as preview
                    const currentVal = tbody.querySelector(`.global-input[data-key="${activePickerKey}"]`)?.value;
                    if (currentVal && modalUploadWidget) {
                        modalUploadWidget.setPreview(currentVal);
                    }
                }
            };
        });

        tbody.querySelectorAll('.image-preview-global').forEach(el => {
            el.onclick = (e) => {
                e.stopPropagation();
                const wasVisible = el.classList.contains('preview-open');

                document.querySelectorAll('.image-preview-global.preview-open').forEach(p => p.classList.remove('preview-open'));

                if (!wasVisible) {
                    el.classList.add('preview-open');
                }
            };
        });

        document.addEventListener('click', () => {
            document.querySelectorAll('.image-preview-global.preview-open').forEach(el => {
                el.classList.remove('preview-open');
            });
        }, { once: false });

        for (const [key] of Object.entries(globals)) {
            const btn = tbody.querySelector(`.save-global-btn[data-key="${key}"]`);
            if (btn) {
                btn.addEventListener('click', async () => {
                    const input = tbody.querySelector(`.global-input[data-key="${key}"]`);
                    const newValue = input.value;
                    const displayName = globals[key]?.name || key;

                    await updateGlobal(key, newValue, displayName);
                });
            }
        }
    } catch (e) {
        console.error(e);
        tbody.innerHTML = '<tr><td colspan="4" class="error-cell">Error loading globals.</td></tr>';
    }
}

/** Update global setting. */
async function updateGlobal(key, value, displayName) {
    let parsedValue = isNaN(value) || value.trim() === '' ? value : parseFloat(value);
    const payload = { value: parsedValue };

    await apiRequest('POST', `/api/globals/${key}`, payload).then(() => {
        notify("Success", `Updated ${displayName}`, 'success');
    }).catch((e) => {
        notify(`Failed to Update ${displayName}`, e, 'error');
    });
}