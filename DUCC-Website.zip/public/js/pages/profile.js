/**
 * profile.js
 * 
 * User Dashboard.
 */

import { LoginEvent } from './login.js';
import { apiRequest, clearApiCache } from '/js/utils/api.js';
import { LegalEvent } from './legal.js';
import { notify } from '/js/components/notification.js';
import { ViewChangedEvent, addRoute, switchView } from '/js/utils/view.js';
import { requireAuth } from '/js/utils/auth.js';
import { getOrdinal } from '/js/utils/utils.js';
import { BalanceChangedEvent } from '/js/utils/events/events.js';
import { showConfirmModal, showPasswordModal, showChangePasswordModal } from '/js/utils/modal.js';
import { Sidebar, initSidebar } from '../widgets/sidebar.js';
import { Panel } from '../widgets/panel.js';
import { StatusIndicator } from '../widgets/status.js';
import { AccentPanel } from '../widgets/accent_panel.js';
import { ValueHeader, updateValueDisplay } from '../widgets/value_header.js';
import { ItemList, StandardListItem } from '../widgets/item_list.js';
import { Tag } from '../widgets/Tag.js';
import {
    SETTINGS_SVG, CLOSE_SVG, SOCIAL_LEADERBOARD_SVG, ID_CARD_SVG, BRIGHTNESS_ALERT_SVG, POOL_SVG, DASHBOARD_SVG, WALLET_SVG,
    LOGOUT_SVG, EDIT_SVG, GROUP_SVG, CONTRACT_SVG, MEDICAL_INFORMATION_SVG, SAVE_SVG, BOLT_SVG, ADD_SVG, REMOVE_SVG
} from '../../images/icons/outline/icons.js';

// Register routes
addRoute('/profile', 'profile');
addRoute('/transactions', 'profile');

const sidebarItems = [
    { id: 'overview', label: 'Overview', icon: DASHBOARD_SVG, active: true },
    { id: 'balance', label: 'Balance & History', icon: WALLET_SVG },
    { id: 'settings', label: 'Account Settings', icon: SETTINGS_SVG },
    { label: 'Sign Out', icon: LOGOUT_SVG, actionId: 'sidebar-logout-btn', classes: 'logout' }
];

/** HTML Template for the dashboard */
const HTML_TEMPLATE = /*html*/`
    <div id="profile-view" class="view hidden">
        <div class="dashboard-container">
            ${Sidebar(sidebarItems)}

            <!-- Main Content Area -->
            <main class="dashboard-content">
        
                <!-- Overview Tab -->
                <section id="tab-overview" class="dashboard-section active">
                    <div id="membership-banner-container"></div>

                    ${Panel({
                        title: 'Swimming Stats',
                        icon: POOL_SVG,
                        action: `<button class="small-btn secondary" data-nav="/swims">${SOCIAL_LEADERBOARD_SVG} View Leaderboard</button>`,
                        content: `<div id="swim-stats-grid" class="stats-grid"><p>Loading stats...</p></div>`
                    })}

                    <!-- Legal & Safety Row -->
                    <div class="dual-grid">
                        ${Panel({
                            title: 'Legal Waiver',
                            icon: CONTRACT_SVG,
                            action: `<button class="small-btn secondary" data-nav="/legal">${EDIT_SVG} Update</button>`,
                            content: `<div id="legal-status-content"><p>Loading...</p></div>`
                        })}

                        ${Panel({
                            title: 'Safety Info',
                            icon: MEDICAL_INFORMATION_SVG,
                            action: `<button id="edit-safety-btn" class="small-btn secondary">${EDIT_SVG} Edit</button>`,
                            content: `
                                <div id="safety-info-display">
                                    <div class="info-rows">
                                        <div class="info-row"><span>First Aid Expiry</span><span id="display-first-aid">Not Set</span></div>
                                        <div class="info-row"><span>Emergency Contact</span><span id="display-emergency">Not Set</span></div>
                                    </div>
                                </div>
                                <form id="safety-info-form" class="hidden modern-form">
                                    <div class="grid-2-col">
                                        <label>First Aid Expiry <input type="date" id="input-first-aid"></label>
                                        <label>Emergency Contact <input type="tel" id="input-emergency" placeholder="07700 900000"></label>
                                    </div>
                                    <div class="form-actions">
                                        <button type="button" id="cancel-safety-btn" class="secondary">${CLOSE_SVG} Cancel</button>
                                        <button type="submit">${SAVE_SVG} Save</button>
                                    </div>
                                </form>
                            `
                        })}
                    </div>

                    ${Panel({
                        id: 'groups-teams-panel',
                        title: 'Groups & Teams',
                        icon: GROUP_SVG,
                        content: `<div id="tags-list-container" class="tags-list"><p>Loading tags...</p></div>`
                    })}

                    ${Panel({
                        content: `
                            <div class="role-toggle">
                                <div class="role-info">
                                    <h4>${BOLT_SVG} Instructor Status</h4>
                                    <p id="instructor-status-text">Not an instructor</p>
                                </div>
                                <button id="toggle-instructor-btn" class="small-btn secondary">Apply</button>
                            </div>
                        `
                    })}
                </section>

                <section id="tab-balance" class="dashboard-section">
                    <!-- Balance Overview -->
                    ${ValueHeader({
                        title: 'Current Balance',
                        value: '£0.00',
                        valueId: 'balance-amount',
                        actions: `<button id="top-up-btn" class="small-btn">Top Up</button>`
                    })}

                    ${Panel({
                        title: 'Transaction History',
                        content: `<div id="transactions-list-container"></div>`
                    })}
                </section>

                <section id="tab-settings" class="dashboard-section">
                    <div class="settings-grid">
                        ${Panel({
                            title: 'Security',
                            icon: ID_CARD_SVG,
                            content: `<button id="change-password-btn" class="outline">Change Password</button>`
                        })}

                        ${Panel({
                            title: 'Danger Zone',
                            icon: BRIGHTNESS_ALERT_SVG,
                            classes: 'danger-zone',
                            content: `<button id="delete-account-btn" class="delete outline">Delete Account</button>`
                        })}
                    </div>
                </section>
            </main>
        </div>
    </div>`;

let currentUser = null;
let sidebarController = null;

// --- Helper Functions ---

function showStatus(title, message, type) {
    notify(title, message, type, 3000, 'profile-status');
}

// --- Render Functions ---

/** Render membership banner. */
function renderMembershipBanner(profile, globals) {
    const container = document.getElementById('membership-banner-container');
    if (!container) return;

    const isMember = profile.is_member;
    const freeSessions = profile.free_sessions || 0;
    const cost = Number(globals.MembershipCost) || 50;

    if (!isMember) {
        container.classList.remove('hidden');
        container.innerHTML = AccentPanel({
            title: "You aren't a member yet",
            text: `You have <strong>${freeSessions}</strong> free trial event${freeSessions !== 1 ? 's' : ''} remaining before membership is required.`,
            buttonText: "Become a Member",
            buttonId: "join-membership-btn"
        });

        document.getElementById('join-membership-btn').onclick = async () => {
            const confirmed = await showConfirmModal(
                "Confirm Membership",
                `Becoming a member costs <strong>£${cost.toFixed(2)}</strong>. This will be added to your account balance. Are you sure?`
            );
            if (confirmed) {
                try {
                    await apiRequest('POST', '/api/user/join');
                    showStatus('Welcome!', 'You are now a club member.', 'success');
                    updateDashboard();
                    BalanceChangedEvent.notify();
                } catch (err) {
                    showStatus('Error', err.message || 'Failed to join.', 'error');
                }
            }
        };
    } else {
        container.classList.add('hidden');
        container.innerHTML = '';
    }
}

/** Render swim stats. */
function renderSwimStats(stats) {
    const grid = document.getElementById('swim-stats-grid');
    const s = stats || { allTime: { swims: 0, rank: '-' }, yearly: { swims: 0, rank: '-' } };

    grid.innerHTML = `
        <div class="stat-item">
            <span class="stat-value">${s.yearly.swims}</span>
            <span class="stat-label">Yearly Swims</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${getOrdinal(s.yearly.rank)}</span>
            <span class="stat-label">Yearly Rank</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${s.allTime.swims}</span>
            <span class="stat-label">Total Swims</span>
        </div>
        <div class="stat-item">
            <span class="stat-value">${getOrdinal(s.allTime.rank)}</span>
            <span class="stat-label">All Time Rank</span>
        </div>
    `;
}

/** Render legal status. */
function renderLegalStatus(profile) {
    const container = document.getElementById('legal-status-content');
    const isComplete = !!profile.filled_legal_info;
    const lastFilled = profile.legal_filled_at ? new Date(profile.legal_filled_at).toLocaleDateString('en-GB') : null;

    container.innerHTML = StatusIndicator({
        active: isComplete,
        activeText: 'Active',
        inactiveText: 'Action Required',
        content: `
            <p>${isComplete ? 'Your legal waiver is up to date.' : 'You must complete the legal waiver to participate in events.'}</p>
            ${isComplete && lastFilled ? `<p class="last-filled">Last filled out: ${lastFilled}</p>` : ''}
        `
    });
}

/** Render safety info. */
function renderSafetyInfo(profile) {
    document.getElementById('display-first-aid').textContent = profile.first_aid_expiry || 'Not Set';
    document.getElementById('display-emergency').textContent = profile.phone_number || 'Not Set';

    document.getElementById('input-first-aid').value = profile.first_aid_expiry || '';
    document.getElementById('input-emergency').value = profile.phone_number || '';
}

/** Render tags. */
function renderTags(tags) {
    const container = document.getElementById('tags-list-container');
    if (tags && tags.length > 0) {
        container.innerHTML = Tag.renderList(tags);
    } else {
        const panel = document.getElementById('groups-teams-panel');
        if (panel) panel.classList.add('hidden');
    }
}

/** Render instructor status. */
function renderInstructor(profile) {
    const isInstructor = profile.is_instructor;
    const text = document.getElementById('instructor-status-text');
    const btn = document.getElementById('toggle-instructor-btn');

    if (isInstructor) {
        text.textContent = 'Active Instructor';
        text.classList.add('instructor-active');
        btn.textContent = 'Resign';
        btn.className = 'small-btn outline delete';
        btn.onclick = async () => {
            if (await showConfirmModal('Resign?', 'Are you sure you want to resign as an instructor?')) {
                await apiRequest('POST', '/api/user/elements', { is_instructor: false });
                updateDashboard();
            }
        };
    } else {
        text.textContent = 'Not an instructor';
        text.classList.remove('instructor-active');
        btn.textContent = 'Apply';
        btn.className = 'small-btn secondary';
        btn.onclick = async () => {
            await apiRequest('POST', '/api/user/elements', { is_instructor: true });
            updateDashboard();
        };
    }
}

/** Update balance display. */
function renderProfileBalance(profile, minMoney) {
    const bal = Number(profile.balance);

    let valueClass = 'balance-warning';
    if (bal < minMoney) valueClass = 'balance-negative';
    else if (bal >= 0) valueClass = 'balance-positive';

    updateValueDisplay('balance-amount', `£${bal.toFixed(2)}`, valueClass);
}

/** Render transaction history. */
async function renderProfileTransactions() {
    const container = document.getElementById('transactions-list-container');
    try {
        const res = await apiRequest('GET', '/api/user/elements/transactions');
        const txs = res.transactions || [];

        container.innerHTML = ItemList(txs, (tx) => {
            const isNegative = tx.amount < 0;
            return StandardListItem({
                icon: isNegative ? REMOVE_SVG : ADD_SVG,
                iconClass: isNegative ? 'negative' : 'positive',
                title: tx.description,
                subtitle: new Date(tx.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
                value: `${isNegative ? '' : '+'}${tx.amount.toFixed(2)}`,
                valueClass: isNegative ? 'negative' : 'positive',
                extra: `£${tx.after !== undefined ? tx.after.toFixed(2) : 'N/A'}`
            });
        });
    } catch (e) {
        container.innerHTML = '<p class="error-text">Failed to load transactions.</p>';
    }
}

// --- Main Update Logic ---

/** Update dashboard. */
async function updateDashboard() {
    if (!await requireAuth()) return;

    try {
        const [profile, globals, tags, minMoneyGlobal] = await Promise.all([
            apiRequest('GET', '/api/user/elements/email,first_name,last_name,is_member,is_instructor,filled_legal_info,legal_filled_at,phone_number,first_aid_expiry,free_sessions,balance,swims,swimmer_rank'),
            apiRequest('GET', '/api/globals/MembershipCost'),
            apiRequest('GET', '/api/user/tags').catch(() => []),
            apiRequest('GET', '/api/globals/MinMoney').catch(() => ({ res: { MinMoney: { data: -25 } } }))
        ]);

        currentUser = profile;
        const minMoney = Number(minMoneyGlobal.res?.MinMoney?.data || -25);

        if (currentUser) {
            renderMembershipBanner(profile, globals.res || {});
            renderSwimStats(profile.swimmer_stats);
            renderLegalStatus(profile);
            renderSafetyInfo(profile);
            renderTags(tags);
            renderInstructor(profile);
        }
        renderProfileBalance(profile, minMoney);
        renderProfileTransactions();

    } catch (error) {
        console.error("Dashboard update failed", error);
        showStatus('Error', 'Failed to load profile data.', 'error');
    }
}

// --- Event Listeners ---

/** Bind events. */
function bindEvents() {
    sidebarController = initSidebar('overview');

    const displayDiv = document.getElementById('safety-info-display');
    const formDiv = document.getElementById('safety-info-form');
    const editBtn = document.getElementById('edit-safety-btn');
    const cancelBtn = document.getElementById('cancel-safety-btn');

    editBtn.onclick = () => {
        displayDiv.classList.add('hidden');
        formDiv.classList.remove('hidden');
        editBtn.classList.add('hidden');
    };

    const closeSafetyEdit = () => {
        displayDiv.classList.remove('hidden');
        formDiv.classList.add('hidden');
        editBtn.classList.remove('hidden');
    };

    cancelBtn.onclick = closeSafetyEdit;

    formDiv.onsubmit = async (e) => {
        e.preventDefault();
        const updateData = {
            first_aid_expiry: document.getElementById('input-first-aid').value,
            phone_number: document.getElementById('input-emergency').value
        };
        try {
            await apiRequest('POST', '/api/user/elements', updateData);
            showStatus('Success', 'Safety info updated.', 'success');
            await updateDashboard();
            closeSafetyEdit();
        } catch (err) {
            showStatus('Error', err.message, 'error');
        }
    };

    // Manual Top Up Instruction Modal
    const topUpBtn = document.getElementById('top-up-btn');
    if (topUpBtn) {
        topUpBtn.onclick = () => {
            const reference = currentUser.first_name.charAt(0).toUpperCase() + currentUser.last_name.toUpperCase() + "WEBSITE";

            showConfirmModal(
                "Top Up Balance",
                `Please transfer the desired amount to:<br><br>
                <strong>Bank:</strong> Durham University<br>
                <strong>Sort Code:</strong> 20-27-66<br>
                <strong>Account:</strong> 53770109<br>
                <strong>Reference:</strong> ${reference}<br><br>
                <p>Pressing the confirm button will notify the finance team to credit your account once the transfer is verified. Please press cancel if you have not made a transfer.</p>`
            );
        };
    }

    // Account Security Listeners
    document.getElementById('change-password-btn').onclick = async () => {
        const passwords = await showChangePasswordModal();
        if (passwords) {
            try {
                await apiRequest('POST', '/api/auth/change-password', passwords);
                showStatus('Success', 'Password changed.', 'success');
            } catch (err) {
                showStatus('Error', 'Failed to change password.', 'error');
            }
        }
    };

    document.getElementById('delete-account-btn').onclick = async () => {
        const password = await showPasswordModal("Delete Account", "This cannot be undone. Enter password to confirm.");
        if (password) {
            try {
                await apiRequest('POST', '/api/user/deleteAccount', { password });
                LoginEvent.notify({ authenticated: false });
                switchView('/home');
            } catch (err) {
                showStatus('Error', 'Delete failed. Check password.', 'error');
            }
        }
    };

    document.getElementById('sidebar-logout-btn').onclick = async () => {
        await apiRequest('GET', '/api/auth/logout');
        clearApiCache();
        LoginEvent.notify({ authenticated: false });
        switchView('/home');
    };
}

document.addEventListener('DOMContentLoaded', () => {
    bindEvents();

    LoginEvent.subscribe(() => updateDashboard());
    LegalEvent.subscribe(() => updateDashboard());
    BalanceChangedEvent.subscribe(() => updateDashboard());

    ViewChangedEvent.subscribe(({ resolvedPath }) => {
        if (resolvedPath === '/profile') {
            const params = new URLSearchParams(window.location.search);
            let tab = params.get('tab') || 'overview';
            const validTabs = ['overview', 'balance', 'settings'];
            if (!validTabs.includes(tab)) tab = 'overview';

            if (sidebarController) sidebarController.setActive(tab);
            updateDashboard();
        }
    });
});

document.querySelector('main').insertAdjacentHTML('beforeend', HTML_TEMPLATE);