/**
 * connection.js
 * 
 * Connectivity monitor.
 */

import { notify, NotificationTypes } from '/js/components/notification.js';
import { ViewChangedEvent, switchView, isCurrentPath } from '/js/utils/view.js';
import { getPreviousPath } from '/js/utils/history.js';
import { apiRequest } from '/js/utils/api.js';
import { NoInternetEvent } from '/js/utils/events/events.js';

let isServerConnected = true;
let currentNotification = null;
let reconnectInterval = null;

/** Update connection status. */
async function updateConnectionStatus(newStatus) {
    if (newStatus === null) {
        apiRequest('GET', '/api/health', false).catch();
        return;
    }        

    if (newStatus === isServerConnected) return;

    if (currentNotification) currentNotification();
    isServerConnected = newStatus;

    if (isServerConnected) {
        if (reconnectInterval) {
            clearInterval(reconnectInterval);
            reconnectInterval = null;
        }

        currentNotification = notify('Connection Restored', 'You are reconnected.', NotificationTypes.SUCCESS, 5000);
        
        if (isCurrentPath('/no-internet')) {
            const prev = getPreviousPath();
            switchView(prev || '/home');
        } else {
            switchView(window.location.pathname, true);
        }
    } else {
        if (!reconnectInterval) {
            reconnectInterval = setInterval(() => {
                updateConnectionStatus(null);
            }, 500);
        }

        currentNotification = notify('Connection Lost', 'Disconnected from server.', NotificationTypes.ERROR, 10000);
        NoInternetEvent.notify();
        switchView('/no-internet');
    }
}

document.addEventListener('DOMContentLoaded', () => {
   ViewChangedEvent.subscribe(path => {
        if (path.viewId === "no-connection") return;
        updateConnectionStatus(null);
    });
});

export { isServerConnected, updateConnectionStatus };