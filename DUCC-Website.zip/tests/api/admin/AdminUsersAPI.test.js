/**
 * AdminUsersAPI.test.js
 * 
 * Admin User Management API tests.
 */

import TestWorld from '../../utils/TestWorld.js';
import AdminUsersAPI from '../../../server/api/admin/AdminUsersAPI.js';
import bcrypt from 'bcrypt';

describe('api/admin/AdminUsersAPI', () => {
    let world;

    beforeEach(async () => {
        world = new TestWorld();
        await world.setUp();
        
        await world.createRole('Admin', ['user.manage', 'user.read', 'transaction.manage', 'role.manage']);
        await world.createRole('Exec', ['event.manage.scoped']);
        await world.createUser('admin', {}, ['Admin']);
        await world.createUser('exec', {}, ['Exec']);
        await world.createUser('user', {});
    });

    afterEach(async () => {
        await world.tearDown();
    });

    describe('GET /api/admin/users (List View)', () => {
        test('Applying filters and pagination to user lists', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();
            await world.createUser('member', { is_member: 1 });
            
            const res = await world.as('admin').get('/api/admin/users?isMember=true');
            expect(res.statusCode).toBe(200);
            expect(res.body.users.every(u => u.is_member === 1)).toBe(true);
        });

        /** Test dynamic field visibility. */
        test('Dynamic field visibility: Admins see all, Scoped Execs see restricted data', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();
            
            // Full Admin check
            const resAdmin = await world.as('admin').get('/api/admin/users');
            expect(resAdmin.body.users[0]).toHaveProperty('email');
            expect(resAdmin.body.users[0]).toHaveProperty('balance');

            // Scoped Exec check
            await world.createTag('T1');
            await world.assignTag('user_managed', 'exec', 'T1');

            const resExec = await world.as('exec').get('/api/admin/users');
            expect(resExec.statusCode).toBe(200);
            const firstUser = resExec.body.users[0];
            expect(firstUser).toHaveProperty('first_name');
            expect(firstUser.email).toBeUndefined();
            expect(firstUser.balance).toBeUndefined();
        });
    });

    describe('GET /api/admin/user/:id (Detail View)', () => {
        /** RBAC-based data filtering in detailed user profiles. */
        test('RBAC-based data filtering in detailed user profiles', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();
            const userId = world.data.users['user'];

            // Admin sees full profile
            const resAdmin = await world.as('admin').get(`/api/admin/user/${userId}`);
            expect(resAdmin.body).toHaveProperty('email');
            expect(resAdmin.body).toHaveProperty('balance');

            // Scoped Exec sees restricted profile
            await world.createTag('T1');
            await world.assignTag('user_managed', 'exec', 'T1');
            const resExec = await world.as('exec').get(`/api/admin/user/${userId}`);
            expect(resExec.body.email).toBeUndefined();
            expect(resExec.body.balance).toBeUndefined();
        });
    });

    describe('President Role Transfer (High-Security Operation)', () => {
        /** Test President role transfer password verification. */
        test('President role transfer requires current user\'s password verification', async () => {
            const password = 'current-password';
            const hashed = await bcrypt.hash(password, 10);
            await world.db.run('UPDATE users SET hashed_password = ? WHERE id = ?', [hashed, world.data.users['admin']]);
            
            await world.db.run('INSERT INTO roles (name) VALUES ("President")');
            const presRole = await world.db.get('SELECT id FROM roles WHERE name = "President"');
            
            const userManagePerm = await world.db.get('SELECT id FROM permissions WHERE slug = "user.manage"');
            const roleManagePerm = await world.db.get('SELECT id FROM permissions WHERE slug = "role.manage"');
            await world.db.run('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [presRole.id, userManagePerm.id]);
            await world.db.run('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [presRole.id, roleManagePerm.id]);

            await world.db.run('DELETE FROM user_roles WHERE user_id = ?', [world.data.users['admin']]);
            await world.db.run('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)', [world.data.users['admin'], presRole.id]);

            const targetId = world.data.users['user'];

            // Inject the hashed password into the session object for the test agent
            world.app.use((req, res, next) => {
                if (req.user && req.user.id === world.data.users['admin']) {
                    req.user.hashed_password = hashed;
                }
                next();
            });
            new AdminUsersAPI(world.app, world.db).registerRoutes();

            // Fail without password
            const res1 = await world.as('admin').post(`/api/admin/user/${targetId}/role`).send({ roleId: presRole.id });
            expect(res1.statusCode).toBe(400);

            // Success with password
            const res2 = await world.as('admin').post(`/api/admin/user/${targetId}/role`).send({ 
                roleId: presRole.id, 
                password: password 
            });
            expect(res2.statusCode).toBe(200);
        });

        /** Test President transfer side-effects. */
        test('Side-effects of President transfer: wipes permissions and scrubs PII', async () => {
            const password = 'password';
            const hashed = await bcrypt.hash(password, 10);
            await world.db.run('UPDATE users SET hashed_password = ? WHERE id = ?', [hashed, world.data.users['admin']]);
            
            await world.db.run('INSERT INTO roles (name) VALUES ("President")');
            const presRole = await world.db.get('SELECT id FROM roles WHERE name = "President"');
            
            const userManagePerm = await world.db.get('SELECT id FROM permissions WHERE slug = "user.manage"');
            const roleManagePerm = await world.db.get('SELECT id FROM permissions WHERE slug = "role.manage"');
            await world.db.run('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [presRole.id, userManagePerm.id]);
            await world.db.run('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [presRole.id, roleManagePerm.id]);

            await world.db.run('DELETE FROM user_roles WHERE user_id = ?', [world.data.users['admin']]);
            await world.db.run('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)', [world.data.users['admin'], presRole.id]);

            const targetId = world.data.users['user'];

            // Setup User A: hasn't agreed to long-term storage
            await world.createUser('to_be_scrubbed', { 
                agrees_to_keep_health_data: 0, 
                home_address: 'Secret Location',
                filled_legal_info: 1
            });
            const scrubbedId = world.data.users['to_be_scrubbed'];

            // Setup User B: has agreed to long-term storage
            await world.createUser('to_be_kept', { 
                agrees_to_keep_health_data: 1, 
                home_address: 'Known Location',
                filled_legal_info: 1
            });
            const keptId = world.data.users['to_be_kept'];

            // Grant some permissions to be wiped
            await world.createRole('ExecRole', ['user.manage']);
            await world.db.run('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)', [keptId, world.data.roles['ExecRole']]);
            await world.createPermission('DirectPerm');
            await world.db.run('INSERT INTO user_permissions (user_id, permission_id) VALUES (?, ?)', [keptId, world.data.perms['DirectPerm']]);

            world.app.use((req, res, next) => {
                if (req.user && req.user.id === world.data.users['admin']) req.user.hashed_password = hashed;
                next();
            });
            new AdminUsersAPI(world.app, world.db).registerRoutes();

            // Perform the transfer
            await world.as('admin').post(`/api/admin/user/${targetId}/role`).send({ roleId: presRole.id, password });

            // Roles and direct permissions are wiped
            const rolesCount = await world.db.get('SELECT COUNT(*) as c FROM user_roles WHERE user_id != ?', [targetId]);
            expect(rolesCount.c).toBe(0);
            const directPermsCount = await world.db.get('SELECT COUNT(*) as c FROM user_permissions');
            expect(directPermsCount.c).toBe(0);

            // GDPR scrubbing performed on User A
            const scrubbed = await world.db.get('SELECT home_address, filled_legal_info FROM users WHERE id = ?', [scrubbedId]);
            expect(scrubbed.home_address).toBeNull();
            expect(scrubbed.filled_legal_info).toBe(0);

            // Data preserved for User B
            const kept = await world.db.get('SELECT home_address, filled_legal_info FROM users WHERE id = ?', [keptId]);
            expect(kept.home_address).toBe('Known Location');
            expect(kept.filled_legal_info).toBe(1);

            // Target user is now President
            const targetRole = await world.db.get('SELECT r.name FROM user_roles ur JOIN roles r ON ur.role_id = r.id WHERE ur.user_id = ?', [targetId]);
            expect(targetRole.name).toBe('President');
        });

        /** Test President takeover prevention. */
        test('Attacker with user.manage should NOT be able to take over President role using their own password', async () => {
            const presidentRoleId = await world.createRole('President', ['user.manage', 'role.manage']);
            const managerRoleId = await world.createRole('Manager', ['user.manage']);

            const adminPassword = 'adminpassword';
            const adminHash = await bcrypt.hash(adminPassword, 10);
            await world.createUser('real_president', { hashed_password: adminHash }, ['President']);

            const attackerPassword = 'attackerpassword';
            const attackerHash = await bcrypt.hash(attackerPassword, 10);
            const attackerId = await world.createUser('attacker', { hashed_password: attackerHash }, ['Manager']);

            new AdminUsersAPI(world.app, world.db).registerRoutes();

            const res = await world.as('attacker').post(`/api/admin/user/${attackerId}/role`).send({
                roleId: presidentRoleId,
                password: attackerPassword
            });

            expect(res.statusCode).toBe(403);
        });
    });

    describe('Role Assignment Authorization (Privilege Escalation Prevention)', () => {
        /** Test role assignment escalation prevention. */
        test('User cannot assign a role containing permissions they do not possess', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();

            await world.createRole('ManagerRole', ['user.manage', 'role.manage']);
            const managerId = await world.createUser('manager', {}, ['ManagerRole']);

            await world.createRole('LimitedRole', ['role.manage', 'event.read.all']);
            const limitedId = await world.createUser('limited', {}, ['LimitedRole']);

            await world.createRole('SuperRole', ['event.manage.all']);
            const superRoleId = world.data.roles['SuperRole'];

            const targetId = await world.createUser('target', {});

            const res = await world.as('limited').post(`/api/admin/user/${targetId}/role`).send({
                roleId: superRoleId
            });

            expect(res.statusCode).toBe(403);
            expect(res.body.message).toMatch(/cannot assign a role with permission/i);
        });

        /** Test hierarchy check. */
        test('User CAN assign a role if they possess an implying higher-level permission (Hierarchy Check)', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();

            await world.createRole('ManagerRole', ['user.manage', 'event.manage.all']);
            const managerId = await world.createUser('manager', {}, ['ManagerRole']);

            await world.createRole('SubRole', ['event.read.all']);
            const subRoleId = world.data.roles['SubRole'];

            const targetId = await world.createUser('target', {});

            const res = await world.as('manager').post(`/api/admin/user/${targetId}/role`).send({
                roleId: subRoleId
            });

            expect(res.statusCode).toBe(200);
        });

        /** Test role assignment with full permissions. */
        test('User CAN assign a role if they possess all permissions in that role', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();

            await world.createRole('ManagerRole', ['user.manage', 'role.manage']);
            const managerId = await world.createUser('manager', {}, ['ManagerRole']);

            await world.createRole('SubRole', ['user.manage']);
            const subRoleId = world.data.roles['SubRole'];

            const targetId = await world.createUser('target', {});

            const res = await world.as('manager').post(`/api/admin/user/${targetId}/role`).send({
                roleId: subRoleId
            });

            expect(res.statusCode).toBe(200);
        });
    });

    describe('Direct Permissions & Tags', () => {
        /** Test direct permission overrides. */
        test('Management of direct user-specific permission and tag scope overrides', async () => {
            new AdminUsersAPI(world.app, world.db).registerRoutes();
            const userId = world.data.users['user'];
            await world.createPermission('custom.perm');
            const permId = world.data.perms['custom.perm'];

            // Grant direct permission
            const res1 = await world.as('admin').post(`/api/admin/user/${userId}/permission`).send({ permissionId: permId });
            expect(res1.statusCode).toBe(200);

            // Grant direct tag scope
            await world.createTag('T1');
            const tagId = world.data.tags['T1'];
            const res2 = await world.as('admin').post(`/api/admin/user/${userId}/managed_tag`).send({ tagId });
            expect(res2.statusCode).toBe(200);

            // Verify via profile fetch
            const res3 = await world.as('admin').get(`/api/admin/user/${userId}`);
            expect(res3.body.direct_permissions.some(p => p.id === permId)).toBe(true);
            expect(res3.body.direct_managed_tags.some(t => t.id === tagId)).toBe(true);
        });
    });
});
