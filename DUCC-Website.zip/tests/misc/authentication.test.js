/**
 * authentication.test.js
 * 
 * Authentication middleware tests.
 */

import checkAuthentication from '../../server/misc/authentication.js';
import { Permissions } from '../../server/misc/permissions.js';

describe('misc/authentication', () => {
    let req, res, next;

    beforeEach(() => {
        // Mock Express Request and Response objects
        req = {
            isAuthenticated: vi.fn().mockReturnValue(true),
            user: { id: 1 },
            db: {}
        };
        res = {
            status: vi.fn().mockReturnThis(),
            json: vi.fn()
        };
        next = vi.fn();
    });

    test('Allow access if authenticated and no permissions are required', async () => {
        const middleware = checkAuthentication();
        await middleware(req, res, next);
        expect(next).toHaveBeenCalled();
    });

    test('Denied (401) if session is not authenticated', async () => {
        req.isAuthenticated.mockReturnValue(false);
        const middleware = checkAuthentication();
        await middleware(req, res, next);
        expect(res.status).toHaveBeenCalledWith(401);
        expect(next).not.toHaveBeenCalled();
    });

    test('Check single permission slug', async () => {
        vi.spyOn(Permissions, 'hasPermission').mockResolvedValue(true);
        const middleware = checkAuthentication('user.manage');
        await middleware(req, res, next);
        
        expect(Permissions.hasPermission).toHaveBeenCalledWith(req.db, 1, 'user.manage');
        expect(next).toHaveBeenCalled();
    });

    test('Denied (403) if user is missing the required permission', async () => {
        vi.spyOn(Permissions, 'hasPermission').mockResolvedValue(false);
        const middleware = checkAuthentication('user.manage');
        await middleware(req, res, next);
        
        expect(res.status).toHaveBeenCalledWith(403);
        expect(next).not.toHaveBeenCalled();
    });

    /** Test OR permission logic. */
    test('Check OR permission logic (| pipe symbol)', async () => {
        // user.read OR user.manage
        vi.spyOn(Permissions, 'hasPermission')
            .mockImplementation(async (db, id, perm) => perm === 'user.manage');
        
        const middleware = checkAuthentication('user.read | user.manage');
        await middleware(req, res, next);
        expect(next).toHaveBeenCalled();
    });

    /** Test special meta-permission: perm:is_exec. */
    test('Check special meta-permission: perm:is_exec', async () => {
        vi.spyOn(Permissions, 'hasAnyPermission').mockResolvedValue(true);
        const middleware = checkAuthentication('perm:is_exec');
        await middleware(req, res, next);
        
        expect(Permissions.hasAnyPermission).toHaveBeenCalledWith(req.db, 1);
        expect(next).toHaveBeenCalled();
    });
});