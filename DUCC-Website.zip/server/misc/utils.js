/**
 * utils.js
 * 
 * Utility functions.
 */

export default class Utils {
    /** Calculate academic year start (Sept 1st). */
    static getAcademicYearStart() {
        const now = new Date();
        const year = now.getUTCMonth() < 8 ? now.getUTCFullYear() - 1 : now.getUTCFullYear();
        return new Date(Date.UTC(year, 8, 1)).toISOString();
    }

    /** Extract base URL from request. */
    static getBaseUrl(req) {
        return `${req.protocol}://${req.get('host')}`;
    }
}
