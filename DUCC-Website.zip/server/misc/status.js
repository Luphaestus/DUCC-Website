/**
 * status.js
 * 
 * Standardized operation results.
 */

export class statusObject {
    /** Initialize status object. */
    constructor(status, message = null, data = null) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    /** Get HTTP status. */
    getStatus() {
        return this.status;
    }

    /** Get message. */
    getMessage() {
        return this.message;
    }

    /** Send JSON response. */
    getResponse(res) {
        if (this.isError()) {
            return res.status(this.getStatus()).json({ message: this.getMessage() });
        }

        return res.status(this.getStatus()).json({ message: this.getMessage(), data: this.getData() });
    }

    /** Check for error. */
    isError() {
        return this.status >= 400;
    }

    /** Get payload data. */
    getData() {
        return this.data;
    }
}