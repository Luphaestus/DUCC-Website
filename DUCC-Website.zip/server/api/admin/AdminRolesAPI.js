/**
 * AdminRolesAPI.js
 * 
 * Role and permission management routes.
 */

import check from '../../misc/authentication.js';
import RolesDB from '../../db/rolesDB.js';

export default class AdminRoles {
    constructor(app, db) {
        this.app = app;
        this.db = db;
    }

    /** Register admin role routes. */
    registerRoutes() {
        /** List system permissions. */
        this.app.get('/api/admin/roles/permissions', check('perm:role.read | perm:role.manage'), async (req, res) => {
            const result = await RolesDB.getAllPermissions(this.db);
            if (result.isError()) return result.getResponse(res);
            res.json(result.getData());
        });

        /** List roles. */
        this.app.get('/api/admin/roles', check('perm:role.manage'), async (req, res) => {
            const result = await RolesDB.getAllRoles(this.db);
            if (result.isError()) return result.getResponse(res);
            res.json(result.getData());
        });

        /** Fetch role by ID. */
        this.app.get('/api/admin/roles/:id', check('perm:role.manage'), async (req, res) => {
            const result = await RolesDB.getRoleById(this.db, req.params.id);
            if (result.isError()) return result.getResponse(res);
            res.json(result.getData());
        });

        /** Create role. */
        this.app.post('/api/admin/roles', check('perm:role.write | perm:role.manage'), async (req, res) => {
            const { name, description, permissions } = req.body;
            const result = await RolesDB.createRole(this.db, name, description, permissions);
            result.getResponse(res);
        });

        /** Update role. */
        this.app.put('/api/admin/roles/:id', check('perm:role.write | perm:role.manage'), async (req, res) => {
            const { name, description, permissions } = req.body;
            const result = await RolesDB.updateRole(this.db, req.params.id, name, description, permissions);
            if (result.isError()) return result.getResponse(res);
            res.json({ message: result.getMessage() });
        });

        /** Delete role. */
        this.app.delete('/api/admin/roles/:id', check('perm:role.write | perm:role.manage'), async (req, res) => {
            const result = await RolesDB.deleteRole(this.db, req.params.id);
            if (result.isError()) return result.getResponse(res);
            res.json({ message: result.getMessage() });
        });
    }
}