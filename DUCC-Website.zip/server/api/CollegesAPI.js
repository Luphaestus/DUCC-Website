/**
 * CollegesAPI.js
 * 
 * College data routes.
 */

import CollegesDB from '../db/collegesDB.js';

export default class CollegesAPI {
    constructor(app, db) {
        this.app = app;
        this.db = db;
    }

    /** Register college routes. */
    registerRoutes() {
        /** List all colleges. */
        this.app.get('/api/colleges', async (req, res) => {
            const result = await CollegesDB.getAll(this.db);
            if (result.isError()) return result.getResponse(res);
            res.json(result.getData());
        });
    }
}