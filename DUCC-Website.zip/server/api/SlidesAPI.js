/**
 * SlidesAPI.js
 * 
 * Home page slideshow image paths.
 */

import { statusObject } from '../misc/status.js';
import SlidesDB from '../db/slidesDB.js';
import check from '../misc/authentication.js';

export default class SlidesAPI {
    constructor(app, db) {
        this.app = app;
        this.db = db;
    }

    /** Register slides routes. */
    registerRoutes() {
        /** Get slide count. */
        this.app.get('/api/slides/count', async (req, res) => {
            const status = await SlidesDB.getSlideCount(this.db);
            status.getResponse(res);
        });

        /** Get all slide image URLs. */
        this.app.get('/api/slides/images', async (req, res) => {
            const status = await SlidesDB.getSlides(this.db);
            if (status.isError()) return status.getResponse(res);
            const slides = status.getData();
            res.json({ 
                images: slides.map(s => s.url),
                slides: slides 
            });
        });

        /** Get random slide image URL. */
        this.app.get('/api/slides/random', async (req, res) => {
            const status = await SlidesDB.getSlides(this.db);
            if (status.isError()) return status.getResponse(res);
            
            const slides = status.getData();
            if (slides.length === 0) return res.status(404).json({ message: 'No slides found' });
            
            const randomSlide = slides[Math.floor(Math.random() * slides.length)];
            res.json({ image: randomSlide.url });
        });

        /** Import file to slideshow. */
        this.app.post('/api/slides/import', check('file.write'), async (req, res) => {
            const { fileId } = req.body;
            if (!fileId) return res.status(400).json({ message: 'fileId is required' });

            const status = await SlidesDB.addSlide(this.db, fileId);
            status.getResponse(res);
        });

        /** Remove slide. */
        this.app.delete('/api/slides', check('file.write'), async (req, res) => {
            const { fileId } = req.body;
            if (!fileId) return res.status(400).json({ message: 'fileId is required' });

            const status = await SlidesDB.removeSlide(this.db, fileId);
            status.getResponse(res);
        });
    }
}