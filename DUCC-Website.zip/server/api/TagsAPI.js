/**
 * TagsAPI.js
 * 
 * Event tag management routes.
 */

import TagsDB from '../db/tagsDB.js';
import check from '../misc/authentication.js';
import { Permissions } from '../misc/permissions.js';

export default class TagsAPI {
    constructor(app, db) {
        this.app = app;
        this.db = db;
    }

    /** Register tag management routes. */
    registerRoutes() {
        /** Fetch all tags. */
        this.app.get('/api/tags', async (req, res) => {
            const result = await TagsDB.getAllTags(this.db);
            result.getResponse(res);
        });

        /** Create new tag. */
        this.app.post('/api/tags', check('perm:event.write.all | perm:manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.createTag(this.db, req.body);
            result.getResponse(res);
        });

        /** Update existing tag. */
        this.app.put('/api/tags/:id', check(), async (req, res) => {
            if (!await Permissions.canManageTag(this.db, req.user.id, req.params.id)) {
                return res.status(403).json({ message: 'Forbidden' });
            }

            const result = await TagsDB.updateTag(this.db, req.params.id, req.body);
            result.getResponse(res);
        });

        /** Reset tag image. */
        this.app.post('/api/tags/:id/reset-image', check(), async (req, res) => {
            if (!await Permissions.canManageTag(this.db, req.user.id, req.params.id)) {
                return res.status(403).json({ message: 'Forbidden' });
            }

            const result = await TagsDB.resetImage(this.db, req.params.id);
            result.getResponse(res);
        });

        /** Delete tag. */
        this.app.delete('/api/tags/:id', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.deleteTag(this.db, req.params.id);
            result.getResponse(res);
        });

        /** Fetch tag whitelist. */
        this.app.get('/api/tags/:id/whitelist', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.getWhitelist(this.db, req.params.id);
            result.getResponse(res);
        });

        /** Add user to whitelist. */
        this.app.post('/api/tags/:id/whitelist', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.addToWhitelist(this.db, req.params.id, req.body.userId);
            result.getResponse(res);
        });

        /** Remove user from whitelist. */
        this.app.delete('/api/tags/:id/whitelist/:userId', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.removeFromWhitelist(this.db, req.params.id, req.params.userId);
            result.getResponse(res);
        });

        /** Fetch tag managers. */
        this.app.get('/api/tags/:id/managers', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.getManagers(this.db, req.params.id);
            result.getResponse(res);
        });

        /** Assign tag manager. */
        this.app.post('/api/tags/:id/managers', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.addManager(this.db, req.params.id, req.body.userId);
            result.getResponse(res);
        });

        /** Remove tag manager. */
        this.app.delete('/api/tags/:id/managers/:userId', check('perm:event.manage.all | perm:user.manage'), async (req, res) => {
            const result = await TagsDB.removeManager(this.db, req.params.id, req.params.userId);
            result.getResponse(res);
        });

        /** Fetch user tags. */
        this.app.get('/api/user/:userId/tags', check(), async (req, res) => {
            if (req.user.id != req.params.userId) {
                if (!await Permissions.hasPermission(this.db, req.user.id, 'user.manage')) {
                    return res.status(403).json({ message: 'Forbidden' });
                }
            }

            try {
                const tags = await TagsDB.getTagsForUser(this.db, req.params.userId);
                res.json(tags);
            } catch (error) {
                res.status(500).json({ message: 'Internal error' });
            }
        });

        /** Fetch current user tags. */
        this.app.get('/api/user/tags', check(), async (req, res) => {
            try {
                const tags = await TagsDB.getTagsForUser(this.db, req.user.id);
                res.json(tags);
            } catch (error) {
                res.status(500).json({ message: 'Internal error' });
            }
        });
    }
}