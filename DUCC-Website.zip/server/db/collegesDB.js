/**
 * collegesDB.js
 * 
 * Database operations for Durham colleges.
 */

import { statusObject } from '../misc/status.js';
import Logger from '../misc/Logger.js';

export default class CollegesDB {
    /** Fetch all colleges. */
    static async getAll(db) {
        try {
            const colleges = await db.all('SELECT * FROM colleges ORDER BY name ASC');
            return new statusObject(200, 'Success', colleges);
        } catch (e) {
            Logger.error('Database error fetching colleges:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch college by ID. */
    static async getCollegeById(db, id) {
        try {
            const college = await db.get('SELECT * FROM colleges WHERE id = ?', [id]);
            return college;
        } catch (e) {
            Logger.error('Database error fetching college by ID:', e);
            return null;
        }
    }
}
