/**
 * eventsDB.js
 * 
 * Core database operations for events.
 */

import { statusObject } from '../misc/status.js';
import TransactionsDB from './transactionDB.js';
import TagsDB from './tagsDB.js';
import UserDB from './userDB.js';
import EventRules from '../rules/EventRules.js';
import Globals from '../misc/globals.js';
import Logger from '../misc/Logger.js';

export default class eventsDB {
    /** Fetch events for a specific week filtered by difficulty. */
    static async get_events_for_week(db, max_difficulty, date = new Date(), userId = null) {
        const startOfWeek = new Date(date);
        startOfWeek.setDate(startOfWeek.getDate() - (startOfWeek.getDay() === 0 ? 6 : startOfWeek.getDay() - 1));
        startOfWeek.setHours(0, 0, 0, 0);

        if (isNaN(startOfWeek.getTime())) {
            return new statusObject(400, 'Invalid date range');
        }

        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(endOfWeek.getDate() + 6);
        endOfWeek.setHours(23, 59, 59, 999);

        const events = await db.all(
            `SELECT e.*, 
             EXISTS(SELECT 1 FROM event_attendees ea WHERE ea.event_id = e.id AND ea.user_id = ? AND ea.is_attending = 1) as is_attending
             FROM events e 
             WHERE e.start BETWEEN ? AND ?
             ORDER BY e.start ASC`,
            [userId, startOfWeek.toISOString(), endOfWeek.toISOString()]
        );

        const visibleEvents = [];
        const user = userId ? (await UserDB.getElementsById(db, userId, ['id', 'is_instructor', 'filled_legal_info', 'is_member', 'free_sessions', 'difficulty_level'])).getData() : null;

        for (const event of events) {
            await this._enrichEvent(db, event);

            if (await EventRules.canViewEvent(db, event, user)) {
                if (user) {
                    const joinStatus = await EventRules.canJoinEvent(db, event, user);
                    event.can_attend = !joinStatus.isError();
                }
                visibleEvents.push(event);
            }
        }

        visibleEvents.sort((a, b) => new Date(a.start) - new Date(b.start));
        return new statusObject(200, null, visibleEvents);
    }

    /** Fetch events for a relative week. */
    static async get_events_relative_week(db, max_difficulty, offset = 0, userId = null) {
        const targetDate = new Date();
        targetDate.setDate(targetDate.getDate() + offset * 7);
        return this.get_events_for_week(db, max_difficulty, targetDate, userId);
    }

    /** Fetch events within a date range. */
    static async get_events_in_range(db, max_difficulty, startDate, endDate, userId = null) {
        const events = await db.all(
            `SELECT e.*,
             (SELECT COUNT(*) FROM event_attendees ea WHERE ea.event_id = e.id AND ea.is_attending = 1) as attendee_count,
             EXISTS(SELECT 1 FROM event_attendees ea WHERE ea.event_id = e.id AND ea.user_id = ? AND ea.is_attending = 1) as is_attending
             FROM events e 
             WHERE e.start >= ? AND e.start <= ?
             ORDER BY e.start ASC`,
            [userId, startDate.toISOString(), endDate.toISOString()]
        );

        const visibleEvents = [];
        const user = userId ? (await UserDB.getElementsById(db, userId, ['id', 'is_instructor', 'filled_legal_info', 'is_member', 'free_sessions', 'difficulty_level'])).getData() : null;

        for (const event of events) {
            await this._enrichEvent(db, event);

            if (await EventRules.canViewEvent(db, event, user)) {
                if (user) {
                    const joinStatus = await EventRules.canJoinEvent(db, event, user);
                    event.can_attend = !joinStatus.isError();
                }
                visibleEvents.push(event);
            }
        }

        visibleEvents.sort((a, b) => new Date(a.start) - new Date(b.start));
        return new statusObject(200, null, visibleEvents);
    }

    /** Administrative fetch of events with filtering. */
    static async getEventsAdmin(db, options) {
        const { page, limit, search, sort, order, showPast, minCost, maxCost, difficulty, location, permissions } = options;
        const offset = (page - 1) * limit;

        const allowedSorts = ['title', 'start', 'location', 'difficulty_level', 'upfront_cost'];
        const sortCol = allowedSorts.includes(sort) ? sort : 'start';
        const sortOrder = order === 'desc' ? 'DESC' : 'ASC';


        let conditions = [];
        const params = [];

        if (search) {
            const terms = search.trim().split(/\s+/);
            terms.forEach(term => {
                const termPattern = `%${term}%`;
                params.push(termPattern, termPattern, termPattern);
                conditions.push(`(title LIKE ? OR location LIKE ? OR description LIKE ?)`);
            });
        }

        if (!showPast) {
            conditions.push(`start >= ?`);
            params.push(new Date().toISOString());
        }

        if (minCost !== undefined && minCost !== '') {
            conditions.push(`upfront_cost >= ?`);
            params.push(parseFloat(minCost));
        }
        if (maxCost !== undefined && maxCost !== '') {
            conditions.push(`upfront_cost <= ?`);
            params.push(parseFloat(maxCost));
        }
        if (difficulty !== undefined && difficulty !== '') {
            conditions.push(`difficulty_level = ?`);
            params.push(parseInt(difficulty));
        }
        if (location && location.trim() !== '') {
            conditions.push(`location LIKE ?`);
            params.push(`%${location.trim()}%`);
        }

        if (permissions !== undefined) {
            if (Array.isArray(permissions) && permissions.length > 0) {
                const tagPlaceholders = permissions.map(() => '?').join(',');
                conditions.push(`id IN (SELECT event_id FROM event_tags WHERE tag_id IN (${tagPlaceholders}))`);
                params.push(...permissions);
            }
        }

        const whereClause = conditions.length > 0 ? 'WHERE ' + conditions.join(' AND ') : '';

        try {
            const query = `SELECT * FROM events ${whereClause} ORDER BY ${sortCol} ${sortOrder} LIMIT ? OFFSET ?`;
            const events = await db.all(query, [...params, limit, offset]);

            for (const event of events) {
                await this._enrichEvent(db, event);
            }

            const countResult = await db.get(`SELECT COUNT(*) as count FROM events ${whereClause}`, params);
            const totalPages = Math.ceil((countResult ? countResult.count : 0) / limit);

            return new statusObject(200, null, { events, totalPages, currentPage: page });
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch event by ID, enforcing visibility. */
    static async get_event_by_id(db, userId, eventId) {
        const event = await db.get('SELECT * FROM events WHERE id = ?', [eventId]);
        if (!event) return new statusObject(404, 'Event not found');

        await this._enrichEvent(db, event);

        const user = userId ? (await UserDB.getElementsById(db, userId, ['difficulty_level', 'id'])).getData() : null;
        if (!await EventRules.canViewEvent(db, event, user)) {
            return new statusObject(401, 'User not authorized');
        }

        return new statusObject(200, null, event);
    }

    /** Fetch event by ID for admin (no visibility checks). */
    static async getEventByIdAdmin(db, id) {
        try {
            const event = await db.get('SELECT * FROM events WHERE id = ?', [id]);
            if (!event) return new statusObject(404, 'Event not found');
            await this._enrichEvent(db, event);
            return new statusObject(200, null, event);
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch raw event details by ID. */
    static async getEventById(db, id) {
        return await db.get('SELECT * FROM events WHERE id = ?', [id]);
    }

    /** Reset event image. */
    static async resetImage(db, id) {
        try {
            await db.run('UPDATE events SET image_id = NULL WHERE id = ?', [id]);
            return new statusObject(200, 'Image reset to default');
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Create new event and link tags. */
    static async createEvent(db, data) {
        try {
            let { title, description, location, start, end, difficulty_level, max_attendees, upfront_cost, tags, signup_required, image_id, upfront_refund_cutoff } = data;
            
            if (!signup_required && max_attendees > 0) {
                return new statusObject(400, 'Max attendees cannot be set if signup is not required');
            }

            const result = await db.run(
                `INSERT INTO events (title, description, location, start, end, difficulty_level, max_attendees, upfront_cost, signup_required, image_id, upfront_refund_cutoff)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [title, description, location, start, end, difficulty_level, max_attendees, upfront_cost, signup_required ? 1 : 0, image_id, upfront_refund_cutoff]
            );
            const eventId = result.lastID;

            if (tags && Array.isArray(tags)) {
                for (const tagId of tags) await TagsDB.associateTag(db, eventId, tagId);
            }

            return new statusObject(201, null, { id: eventId });
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Update event and tags. */
    static async updateEvent(db, id, data) {
        try {
            let { title, description, location, start, end, difficulty_level, max_attendees, upfront_cost, tags, signup_required, image_id, upfront_refund_cutoff } = data;

            if (!signup_required && max_attendees > 0) {
                return new statusObject(400, 'Max attendees cannot be set if signup is not required');
            }

            await db.run(
                `UPDATE events SET title=?, description=?, location=?, start=?, end=?, difficulty_level=?, max_attendees=?, upfront_cost=?, signup_required=?, image_id=?, upfront_refund_cutoff=? WHERE id=?`,
                [title, description, location, start, end, difficulty_level, max_attendees, upfront_cost, signup_required ? 1 : 0, image_id, upfront_refund_cutoff, id]
            );

            if (tags && Array.isArray(tags)) {
                await TagsDB.clearEventTags(db, id);
                for (const tagId of tags) await TagsDB.associateTag(db, id, tagId);
            }

            return new statusObject(200, 'Event updated');
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error: ' + error.message);
        }
    }

    /** Toggle event cancellation. */
    static async setEventCancellation(db, id, isCanceled) {
        try {
            await db.run("UPDATE events SET is_canceled = ? WHERE id = ?", [isCanceled ? 1 : 0, id]);
            return new statusObject(200, 'Event cancellation status updated');
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Cancel event and process refunds. */
    static async cancelEvent(db, id) {
        try {
            await db.run('BEGIN TRANSACTION');

            const event = await db.get('SELECT * FROM events WHERE id = ?', [id]);
            if (!event) {
                await db.run('ROLLBACK');
                return new statusObject(404, 'Event not found');
            }

            if (event.is_canceled) {
                await db.run('ROLLBACK');
                return new statusObject(400, 'Event already canceled');
            }

            await db.run("UPDATE events SET is_canceled = 1 WHERE id = ?", [id]);

            const attendees = await db.all('SELECT * FROM event_attendees WHERE event_id = ? AND is_attending = 1', [id]);

            for (const attendee of attendees) {
                if (attendee.payment_transaction_id) {
                    const transaction = await db.get('SELECT * FROM transactions WHERE id = ?', [attendee.payment_transaction_id]);
                    if (transaction) {
                        const refundAmount = Math.abs(transaction.amount);
                        await TransactionsDB._add_transaction_internal(db, attendee.user_id, refundAmount, `Refund for canceled event: ${event.title}`, id);
                    }
                } 
                
                const user = await db.get('SELECT is_member FROM users WHERE id = ?', [attendee.user_id]);
                if (user && !user.is_member) {
                    await db.run('UPDATE users SET free_sessions = free_sessions + 1 WHERE id = ?', [attendee.user_id]);
                }
            }

            await db.run('DELETE FROM event_waiting_list WHERE event_id = ?', [id]);

            await db.run('COMMIT');
            return new statusObject(200, 'Event canceled and refunds processed');
        } catch (error) {
            await db.run('ROLLBACK');
            Logger.error(error);
            return new statusObject(500, 'Database error during cancellation');
        }
    }

    /** Delete event record. */
    static async deleteEvent(db, id) {
        try {
            await db.run('DELETE FROM events WHERE id = ?', [id]);
            return new statusObject(200, 'Event deleted');
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Enrich event with tags and image URL. */
    static async _enrichEvent(db, event) {
        event.tags = await TagsDB.getTagsForEvent(db, event.id);
        if (event.image_id) {
            event.image_url = `/api/files/${event.image_id}/download?view=true`;
        } else {
            event.image_url = await this._getFallbackImage(db, event.tags);
        }
    }

    /** Calculate fallback image. */
    static async _getFallbackImage(db, tags) {
        if (tags && tags.length > 0) {
            const bestTag = tags
                .filter(t => t.image_id !== null)
                .sort((a, b) => b.priority - a.priority)[0];
            
            if (bestTag) {
                return `/api/files/${bestTag.image_id}/download?view=true`;
            }
        }
        
        return new Globals().get('DefaultEventImage').data;
    }
}
