/**
 * rolesDB.js
 * 
 * RBAC database management.
 */

import { statusObject } from '../misc/status.js';
import { SCOPED_PERMS, Permissions } from '../misc/permissions.js';
import Logger from '../misc/Logger.js';

export default class RolesDB {
    /** Fetch role name by ID. */
    static async getRoleNameById(db, id) {
        const role = await db.get('SELECT name FROM roles WHERE id = ?', [id]);
        return role ? role.name : null;
    }

    /** Fetch user roles. */
    static async getUserRoles(db, userId) {
        try {
            const roles = await db.all('SELECT r.id, r.name FROM roles r JOIN user_roles ur ON r.id = ur.role_id WHERE ur.user_id = ?', [userId]);
            return new statusObject(200, 'Success', roles);
        } catch (e) {
            Logger.error('Database error fetching user roles:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Assign role to user. */
    static async assignRole(db, userId, roleId) {
        try {
            await db.run('DELETE FROM user_roles WHERE user_id = ?', [userId]);
            await db.run('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)', [userId, roleId]);
            return new statusObject(200, 'Role assigned');
        } catch (e) {
            Logger.error('Database error assigning role:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Remove role from user. */
    static async removeRole(db, userId, roleId) {
        try {
            const role = await db.get('SELECT name FROM roles WHERE id = ?', [roleId]);
            if (role && role.name === 'President') {
                return new statusObject(403, 'The President role cannot be removed.');
            }
            await db.run('DELETE FROM user_roles WHERE user_id = ? AND role_id = ?', [userId, roleId]);
            return new statusObject(200, 'Role removed');
        } catch (e) {
            Logger.error('Database error removing role:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch direct user permissions. */
    static async getUserPermissions(db, userId) {
        try {
            const perms = await db.all(
                `SELECT p.id, p.slug, p.description FROM permissions p 
                 JOIN user_permissions up ON p.id = up.permission_id 
                 WHERE up.user_id = ?`,
                [userId]
            );
            return new statusObject(200, 'Success', perms);
        } catch (e) {
            Logger.error('Database error fetching user permissions:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Get all user permission slugs. */
    static async getAllUserPermissions(db, userId) {
        try {
            const rolePerms = await db.all(`
                SELECT DISTINCT p.slug 
                FROM permissions p
                JOIN role_permissions rp ON p.id = rp.permission_id
                JOIN user_roles ur ON rp.role_id = ur.role_id
                WHERE ur.user_id = ?
            `, [userId]);
            
            const directPerms = await db.all(`
                SELECT DISTINCT p.slug 
                FROM permissions p
                JOIN user_permissions up ON p.id = up.permission_id
                WHERE up.user_id = ?
            `, [userId]);

            const allSlugs = new Set([
                ...rolePerms.map(p => p.slug), 
                ...directPerms.map(p => p.slug)
            ]);
            
            return new statusObject(200, 'Success', Array.from(allSlugs));
        } catch (e) {
            Logger.error('Database error fetching all user permissions:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Add direct permission to user. */
    static async addUserPermission(db, userId, permissionId) {
        try {
            const perm = await db.get('SELECT slug FROM permissions WHERE id = ?', [permissionId]);
            if (!perm) {
                return new statusObject(404, 'Permission not found.');
            }
            if (SCOPED_PERMS.includes(perm.slug)) {
                return new statusObject(400, 'Scoped permissions are assigned automatically and cannot be set manually.');
            }

            await db.run('INSERT OR IGNORE INTO user_permissions (user_id, permission_id) VALUES (?, ?)', [userId, permissionId]);
            return new statusObject(200, 'Permission added');
        } catch (e) {
            Logger.error('Database error adding user permission:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Remove direct user permission. */
    static async removeUserPermission(db, userId, permissionId) {
        try {
            await db.run('DELETE FROM user_permissions WHERE user_id = ? AND permission_id = ?', [userId, permissionId]);
            return new statusObject(200, 'Permission removed');
        } catch (e) {
            Logger.error('Database error removing user permission:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch user managed tags. */
    static async getUserManagedTags(db, userId) {
        try {
            const tags = await db.all(
                `SELECT t.id, t.name, t.color FROM tags t
                 JOIN user_managed_tags umt ON t.id = umt.tag_id
                 WHERE umt.user_id = ?`,
                [userId]
            );
            return new statusObject(200, 'Success', tags);
        } catch (e) {
            Logger.error('Database error fetching user managed tags:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Add managed tag scope. */
    static async addManagedTag(db, userId, tagId) {
        try {
            await db.run('INSERT OR IGNORE INTO user_managed_tags (tag_id, user_id) VALUES (?, ?)', [tagId, userId]);
            return new statusObject(200, 'Tag scope added');
        } catch (e) {
            Logger.error('Database error adding managed tag:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Remove managed tag scope. */
    static async removeManagedTag(db, userId, tagId) {
        try {
            await db.run('DELETE FROM user_managed_tags WHERE user_id = ? AND tag_id = ?', [userId, tagId]);
            return new statusObject(200, 'Tag scope removed');
        } catch (e) {
            Logger.error('Database error removing managed tag:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Check if user has role for tag. */
    static async hasRoleForTag(db, userId, tagId) {
        const hasRole = await db.get(
            `SELECT 1 FROM user_roles ur
             JOIN role_managed_tags rmt ON ur.role_id = rmt.role_id
             WHERE ur.user_id = ? AND rmt.tag_id = ?`,
            [userId, tagId]
        );
        return !!hasRole;
    }

    /** Fetch all permissions. */
    static async getAllPermissions(db) {
        try {
            let perms = await db.all('SELECT * FROM permissions ORDER BY slug ASC');
            perms = Permissions.filterScopedPerms(perms.map(p => p.slug)).map(slug => perms.find(p => p.slug === slug));
            return new statusObject(200, 'Success', perms);
        } catch (e) {
            Logger.error('Database error fetching permissions:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch all roles with permissions. */
    static async getAllRoles(db) {
        try {
            const roles = await db.all('SELECT * FROM roles');
            for (const role of roles) {
                const perms = await db.all(
                    `SELECT p.slug FROM permissions p 
                     JOIN role_permissions rp ON p.id = rp.permission_id 
                     WHERE rp.role_id = ?`,
                    [role.id]
                );
                role.permissions = perms.map(p => p.slug);
            }
            return new statusObject(200, 'Success', roles);
        } catch (e) {
            Logger.error('Database error fetching roles:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch role by ID. */
    static async getRoleById(db, id) {
        try {
            const role = await db.get('SELECT * FROM roles WHERE id = ?', [id]);
            if (!role) return new statusObject(404, 'Role not found');

            const perms = await db.all(
                `SELECT p.slug FROM permissions p 
                 JOIN role_permissions rp ON p.id = rp.permission_id 
                 WHERE rp.role_id = ?`,
                [id]
            );
            role.permissions = perms.map(p => p.slug);
            
            return new statusObject(200, 'Success', role);
        } catch (e) {
            Logger.error('Database error fetching role by ID:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Create new role. */
    static async createRole(db, name, description, permissions) {
        try {
            const existingRole = await db.get('SELECT id FROM roles WHERE name = ?', [name]);
            if (existingRole) {
                return new statusObject(409, 'A role with this name already exists.');
            }

            const result = await db.run('INSERT INTO roles (name, description) VALUES (?, ?)', [name, description]);
            const roleId = result.lastID;

            if (permissions && Array.isArray(permissions)) {
                permissions = Permissions.filterScopedPerms(permissions);
                for (const slug of permissions) {
                    const perm = await db.get('SELECT id FROM permissions WHERE slug = ?', [slug]);
                    if (perm) {
                        await db.run('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [roleId, perm.id]);
                    }
                }
            }
            return new statusObject(201, 'Role created', { id: roleId });
        } catch (e) {
            Logger.error('Database error creating role:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Update existing role. */
    static async updateRole(db, id, name, description, permissions) {
        try {
            const role = await db.get('SELECT name FROM roles WHERE id = ?', [id]);
            if (role && role.name === 'President') {
                return new statusObject(403, 'The President role cannot be updated.');
            }

            await db.run('UPDATE roles SET name = ?, description = ? WHERE id = ?', [name, description, id]);

            if (permissions && Array.isArray(permissions)) {
                await db.run('DELETE FROM role_permissions WHERE role_id = ?', [id]);
                permissions = Permissions.filterScopedPerms(permissions);
                for (const slug of permissions) {
                    const perm = await db.get('SELECT id FROM permissions WHERE slug = ?', [slug]);
                    if (perm) {
                        await db.run('INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)', [id, perm.id]);
                    }
                }
            }
            return new statusObject(200, 'Role updated');
        } catch (e) {
            Logger.error('Database error updating role:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Delete role. */
    static async deleteRole(db, id) {
        try {
            const role = await db.get('SELECT name FROM roles WHERE id = ?', [id]);
            if (role && role.name === 'President') {
                return new statusObject(403, 'The President role cannot be deleted.');
            }

            await db.run('DELETE FROM roles WHERE id = ?', [id]);
            return new statusObject(200, 'Role deleted');
        } catch (e) {
            Logger.error('Database error deleting role:', e);
            return new statusObject(500, 'Database error');
        }
    }

    /** Find first user ID by role name. */
    static async getFirstUserIdByRoleName(db, roleName) {
        try {
            const role = await db.get('SELECT id FROM roles WHERE name = ?', [roleName]);
            if (!role) return new statusObject(404, 'Role not found');

            const result = await db.get('SELECT user_id FROM user_roles WHERE role_id = ?', [role.id]);
            if (!result) return new statusObject(404, 'User not found in role');

            return new statusObject(200, 'Success', result.user_id);
        } catch (e) {
            Logger.error('Database error fetching first user by role name:', e);
            return new statusObject(500, 'Database error');
        }
    }
}
