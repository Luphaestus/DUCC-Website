/**
 * tagsDB.js
 * 
 * Event tag lifecycle and whitelist management.
 */

import { statusObject } from '../misc/status.js';
import FileCleanup from '../misc/FileCleanup.js';
import Logger from '../misc/Logger.js';

export default class TagsDB {
    /** Fetch all tags. */
    static async getAllTags(db) {
        try {
            const tags = await db.all('SELECT * FROM tags ORDER BY name ASC');
            return new statusObject(200, null, tags);
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch tag metadata by ID. */
    static async getTagById(db, id) {
        try {
            const tag = await db.get('SELECT * FROM tags WHERE id = ?', [id]);
            if (!tag) return new statusObject(404, 'Tag not found');
            return new statusObject(200, null, tag);
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch list of tags by IDs. */
    static async getTagListByIds(db, ids) {
        const placeholders = ids.map(() => '?').join(',');
        return await db.all(`SELECT * FROM tags WHERE id IN (${placeholders})`, ids);
    }

    /** Create new tag. */
    static async createTag(db, data) {
        try {
            const { name, color, description, min_difficulty, priority, join_policy, view_policy, image_id } = data;
            const result = await db.run(
                'INSERT INTO tags (name, color, description, min_difficulty, priority, join_policy, view_policy, image_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [name, color || '#808080', description, min_difficulty, priority || 0, join_policy || 'open', view_policy || 'open', image_id]
            );
            return new statusObject(201, null, { id: result.lastID });
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Update tag metadata. */
    static async updateTag(db, id, data) {
        try {
            const { name, color, description, min_difficulty, priority, join_policy, view_policy, image_id } = data;
            
            const oldTag = await db.get('SELECT image_id FROM tags WHERE id = ?', [id]);
            
            await db.run(
                'UPDATE tags SET name=?, color=?, description=?, min_difficulty=?, priority=?, join_policy=?, view_policy=?, image_id=? WHERE id=?',
                [name, color, description, min_difficulty, priority, join_policy, view_policy, image_id, id]
            );

            if (oldTag && oldTag.image_id !== image_id) {
                await FileCleanup.checkAndDeleteIfUnused(db, oldTag.image_id);
            }

            return new statusObject(200, 'Tag updated');
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Reset tag image. */
    static async resetImage(db, id) {
        try {
            const tag = await db.get('SELECT image_id FROM tags WHERE id = ?', [id]);
            await db.run('UPDATE tags SET image_id = NULL WHERE id = ?', [id]);
            
            if (tag) await FileCleanup.checkAndDeleteIfUnused(db, tag.image_id);
            
            return new statusObject(200, 'Image removed');
        } catch (error) {
            Logger.error(error);
            return new statusObject(500, 'Database error');
        }
    }

    /** Delete tag. */
    static async deleteTag(db, id) {
        try {
            const tag = await db.get('SELECT image_id FROM tags WHERE id = ?', [id]);
            await db.run('DELETE FROM tags WHERE id = ?', [id]);
            
            if (tag) {
                await FileCleanup.checkAndDeleteIfUnused(db, tag.image_id);
            }
            
            return new statusObject(200, 'Tag deleted');
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Fetch tag whitelist. */
    static async getWhitelist(db, tagId) {
        try {
            const users = await db.all(`
                SELECT u.id, u.first_name, u.last_name, u.email
                FROM users u
                JOIN tag_whitelists tw ON u.id = tw.user_id
                WHERE tw.tag_id = ?
            `, [tagId]);
            return new statusObject(200, null, users);
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Add user to whitelist. */
    static async addToWhitelist(db, tagId, userId) {
        try {
            await db.run('INSERT OR IGNORE INTO tag_whitelists (tag_id, user_id) VALUES (?, ?)', [tagId, userId]);
            return new statusObject(200, 'User added to whitelist');
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Remove user from whitelist. */
    static async removeFromWhitelist(db, tagId, userId) {
        try {
            await db.run('DELETE FROM tag_whitelists WHERE tag_id = ? AND user_id = ?', [tagId, userId]);
            return new statusObject(200, 'User removed from whitelist');
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Check if user is whitelisted. */
    static async isWhitelisted(db, tagId, userId) {
        const whitelisted = await db.get(
            'SELECT 1 FROM tag_whitelists WHERE tag_id = ? AND user_id = ?',
            [tagId, userId]
        );
        return !!whitelisted;
    }

    /** Fetch tag managers. */
    static async getManagers(db, tagId) {
        try {
            const users = await db.all(`
                SELECT u.id, u.first_name, u.last_name, u.email
                FROM users u
                JOIN user_managed_tags umt ON u.id = umt.user_id
                WHERE umt.tag_id = ?
            `, [tagId]);
            return new statusObject(200, null, users);
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Add tag manager. */
    static async addManager(db, tagId, userId) {
        try {
            await db.run('INSERT OR IGNORE INTO user_managed_tags (tag_id, user_id) VALUES (?, ?)', [tagId, userId]);
            return new statusObject(200, 'Manager added');
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Remove tag manager. */
    static async removeManager(db, tagId, userId) {
        try {
            await db.run('DELETE FROM user_managed_tags WHERE tag_id = ? AND user_id = ?', [tagId, userId]);
            return new statusObject(200, 'Manager removed');
        } catch (error) {
            return new statusObject(500, 'Database error');
        }
    }

    /** Link tag to event. */
    static async associateTag(db, eventId, tagId) {
        await db.run('INSERT OR IGNORE INTO event_tags (event_id, tag_id) VALUES (?, ?)', [eventId, tagId]);
    }

    /** Remove all event tag associations. */
    static async clearEventTags(db, eventId) {
        await db.run('DELETE FROM event_tags WHERE event_id = ?', [eventId]);
    }

    /** Fetch tags for event. */
    static async getTagsForEvent(db, eventId) {
        return db.all(`
            SELECT t.* 
            FROM tags t
            JOIN event_tags et ON t.id = et.tag_id
            WHERE et.event_id = ?
        `, [eventId]);
    }

    /** Fetch tags for user. */
    static async getTagsForUser(db, userId) {
        return db.all(`
            SELECT t.* 
            FROM tags t
            JOIN tag_whitelists tw ON t.id = tw.tag_id
            WHERE tw.user_id = ?
        `, [userId]);
    }
}
