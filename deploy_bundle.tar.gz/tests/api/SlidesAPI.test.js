/**
 * SlidesAPI.test.js
 * 
 * Slideshow image API tests.
 */

import SlidesAPI from '../../server/api/SlidesAPI.js';
import TestWorld from '../utils/TestWorld.js';

describe('api/SlidesAPI', () => {
    let world;
    let slidesAPI;

    beforeEach(async () => {
        world = new TestWorld();
        await world.setUp();
        
        slidesAPI = new SlidesAPI(world.app, world.db);
        slidesAPI.registerRoutes();
        await world.app.ready();
    });

    afterEach(async () => {
        await world.tearDown();
    });

    test('GET /api/slides/count', async () => {
        const fileId = await world.createFile('Slide1');
        await world.db.run('INSERT INTO slides (file_id) VALUES (?)', [fileId]);

        const res = await world.request.get('/api/slides/count');
        expect(res.statusCode).toBe(200);
        expect(JSON.parse(res.body).data).toBe(1);
    });

    test('GET /api/slides/images', async () => {
        const fileId = await world.createFile('Slide1');
        await world.db.run('INSERT INTO slides (file_id) VALUES (?)', [fileId]);

        const res = await world.request.get('/api/slides/images');
        expect(res.statusCode).toBe(200);
        expect(JSON.parse(res.body).images).toContain(`/api/files/${fileId}/download?view=true`);
    });

    test('GET /api/slides/random', async () => {
        const fileId = await world.createFile('Slide1');
        await world.db.run('INSERT INTO slides (file_id) VALUES (?)', [fileId]);

        const res = await world.request.get('/api/slides/random');
        expect(res.statusCode).toBe(200);
        expect(JSON.parse(res.body).image).toBe(`/api/files/${fileId}/download?view=true`);
    });

    test('POST /api/slides/import and DELETE /api/slides', async () => {
        await world.createRole('admin', ['file.write']);
        await world.createUser('admin', {}, ['admin']);
        const fileId = await world.createFile('Slide1');

        // Import
        const resImport = await world.as('admin').post('/api/slides/import', { fileId });
        expect(resImport.statusCode).toBe(201);

        const countRes = await world.request.get('/api/slides/count');
        expect(JSON.parse(countRes.body).data).toBe(1);

        // Delete
        const resDelete = await world.as('admin').delete('/api/slides', { fileId });
        expect(resDelete.statusCode).toBe(200);

        const countRes2 = await world.request.get('/api/slides/count');
        expect(JSON.parse(countRes2.body).data).toBe(0);
    });
});
