/**
 * attendanceDB.test.js
 * 
 * Event attendance DB tests.
 */

import TestWorld from '../utils/TestWorld.js';
import AttendanceDB from '../../server/db/attendanceDB.js';

describe('db/attendanceDB', () => {
    let world;

    beforeEach(async () => {
        world = new TestWorld();
        await world.setUp();
        await world.createUser('user', {});
        await world.createEvent('Event1');
    });

    afterEach(async () => {
        await world.tearDown();
    });

    /** Test attend event toggle. */
    test('attend_event correctly records participation and is_user_attending_event detects it', async () => {
        const userId = world.data.users['user'];
        const eventId = world.data.events['Event1'];

        // Initial state check
        let res = await AttendanceDB.is_user_attending_event(world.db, userId, eventId);
        expect(res.getData()).toBe(false);

        // Action: join
        await AttendanceDB.attend_event(world.db, userId, eventId);
        
        // Final state check
        res = await AttendanceDB.is_user_attending_event(world.db, userId, eventId);
        expect(res.getData()).toBe(true);
    });

    /** Test leave event. */
    test('leave_event correctly marks the user as no longer attending', async () => {
        const userId = world.data.users['user'];
        const eventId = world.data.events['Event1'];

        await AttendanceDB.attend_event(world.db, userId, eventId);
        await AttendanceDB.leave_event(world.db, userId, eventId);

        const res = await AttendanceDB.is_user_attending_event(world.db, userId, eventId);
        expect(res.getData()).toBe(false);
    });

    /** Test coach count. */
    test('getCoachesAttendingCount correctly filters and counts instructors', async () => {
        const eventId = world.data.events['Event1'];
        
        await world.createUser('coach', { is_instructor: 1 });
        const coachId = world.data.users['coach'];
        
        // Zero state
        expect(await AttendanceDB.getCoachesAttendingCount(world.db, eventId)).toBe(0);

        // Joined state
        await AttendanceDB.attend_event(world.db, coachId, eventId);
        expect(await AttendanceDB.getCoachesAttendingCount(world.db, eventId)).toBe(1);
    });
});